Specifications from customer

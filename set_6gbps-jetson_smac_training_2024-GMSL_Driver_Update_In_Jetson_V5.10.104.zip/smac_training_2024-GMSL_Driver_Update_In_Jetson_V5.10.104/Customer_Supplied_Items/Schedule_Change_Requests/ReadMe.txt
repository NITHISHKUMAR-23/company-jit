Schedule change requests from customer

The Customer supplied documents for the specific task

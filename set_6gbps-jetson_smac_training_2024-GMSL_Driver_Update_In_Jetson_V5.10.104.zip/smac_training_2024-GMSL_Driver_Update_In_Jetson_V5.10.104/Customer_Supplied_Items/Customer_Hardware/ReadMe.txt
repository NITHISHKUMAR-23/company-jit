Hardware related details received from customer

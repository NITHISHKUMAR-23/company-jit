The different versions released for testing and certification. Each release folder contains the following folders:

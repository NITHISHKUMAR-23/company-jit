pre-order stage documents for the specific task

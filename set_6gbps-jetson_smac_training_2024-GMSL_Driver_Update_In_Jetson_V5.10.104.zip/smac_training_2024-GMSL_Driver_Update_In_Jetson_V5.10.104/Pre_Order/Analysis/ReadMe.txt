Feasibility and other analysis details

Proposal presentation

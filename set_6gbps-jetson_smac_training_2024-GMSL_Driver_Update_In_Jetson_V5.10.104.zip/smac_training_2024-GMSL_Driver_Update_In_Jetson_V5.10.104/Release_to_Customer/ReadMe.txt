The different versions released for customer. Each release folder contains the following folders:

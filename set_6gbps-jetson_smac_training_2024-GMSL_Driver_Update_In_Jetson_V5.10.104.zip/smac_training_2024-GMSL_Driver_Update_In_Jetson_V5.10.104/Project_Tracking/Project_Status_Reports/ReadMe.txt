Project status reports as provided to senior management and customer

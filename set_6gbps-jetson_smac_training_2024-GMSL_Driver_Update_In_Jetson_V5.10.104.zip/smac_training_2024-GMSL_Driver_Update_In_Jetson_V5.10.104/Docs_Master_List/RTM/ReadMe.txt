The RTM document

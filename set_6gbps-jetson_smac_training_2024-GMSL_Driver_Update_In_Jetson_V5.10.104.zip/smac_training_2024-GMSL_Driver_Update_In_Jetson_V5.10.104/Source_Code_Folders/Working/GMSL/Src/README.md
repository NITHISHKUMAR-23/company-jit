Linux kernel
============

The source code of this kernel & its build steps are provided in the below mentioned document.

https://jasmininfo-my.sharepoint.com/:w:/g/personal/kanimozhi_t_jasmin-infotech_com/IQCXLm4X1mhLQLKx9JpqeN6lAWoguzK0t0-AOZZgL70Xgl0?e=xg6IRS


Note: The kernel version is ``5.10.104``.
# GMSL Demo project

# Overview

  This GMSL setup enables live video preview from multiple camera inputs using high-speed GMSL links and MIPI interfaces. One IMX219 camera is connected through a serializer (MAX96717-AAK-EVK) and adapter, another IMX219 camera is connected through an adapter (AD-GMSL717MIPI-EVK), and the STURDeCAM25 GMSL2 Global Shutter Camera is connected directly to the MAX96724-BAK-EVK deserializer. All video streams are processed in real time by the NVIDIA Jetson Orin Nano Super Developer Kit, providing advanced features such as drowsiness detection, object detection, face blur, and face recognition.

---

![GMSL Demo setup](GMSL_Demo_setup.jpg)

## Hardware Components

- **IMX219 RPi v2 Camera (x2)**  
  Standard Raspberry Pi camera modules.

- **AD-GMSLCAMRPI-ADP (Input Adapter Board)**  
  Interface adapter for connecting IMX219 to GMSL serializer boards.

- **Serializer: MAX96717-AAK-EVK**  
  Converts MIPI CSI-2 signals from the camera into GMSL2 streams.

- **ADGMSL717 MIPI EVK**  
  Evaluation kit for connecting IMX219 to GMSL2.

- **STURDeCAM25**  
  IP67 Full HD global shutter GMSL2 camera module.  
  Directly outputs GMSL2, no separate serializer required.

- **Deserializer: MAX96724-BAK-EVK**  
  Converts incoming GMSL2 streams back into MIPI CSI-2.  
  Supports multiple camera inputs.

- **AD-GMSLCAMRPI-ADP (Output Adapter Board)**  
  Routes deserialized MIPI CSI-2 signals to the Jetson board.

- **NVIDIA Jetson Orin Nano Super Developer Kit**  
  Processes video streams from multiple cameras.  
  Runs AI/vision applications for analysis.

---

## Connection Flow

1.  i. **IMX219 → Adapter(AD-GMSLCAMRPI-ADP) → Serializer (MAX96717)**  
    Camera outputs MIPI CSI-2, converted into GMSL2.

    ii **IMX219 → ADGMSL717 MIPI EVK (Has inbuild Serializer)**  
    Camera outputs MIPI CSI-2, converted into GMSL2.
    
    iii. **STURDeCAM25 → Deserializer**   
    Camera outputs, converted into GMSL2.

2. **Serializer → Deserializer (MAX96724)**  
   Transmission over coaxial cable using GMSL2.

3. **Deserializer → Adapter → Jetson Orin Nano**  
   GMSL2 streams are deserialized into MIPI CSI-2 for Jetson input.

4. **Jetson Application**  
   Receives video streams, processes, and combines them as needed.

---

## Workflow

1. cameras capture video streams.  
2. MAX96717 serializer converts them into GMSL2 streams.  
3. GMSL2 signals are transmitted via coaxial cables.  
4. MAX96724 deserializer converts GMSL2 back to MIPI CSI-2.  
5. Jetson Orin Nano receives streams and processes them using AI/vision applications.  

---

## Applications

- Drowsiness detection.  
- Face Blur.  
- Object detection.  
- Face detection.

---


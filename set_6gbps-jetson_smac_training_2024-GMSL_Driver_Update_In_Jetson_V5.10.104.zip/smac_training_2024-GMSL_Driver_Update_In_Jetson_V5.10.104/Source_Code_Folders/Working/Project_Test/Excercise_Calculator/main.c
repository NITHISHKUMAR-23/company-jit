#Sample project for exercise 4
# Write fucntions of calculator in seperate file and call from the main

void main()
{
    printf("Welcome to Calculator Applicaiton \n");
    // call funciton
    // print its result
}
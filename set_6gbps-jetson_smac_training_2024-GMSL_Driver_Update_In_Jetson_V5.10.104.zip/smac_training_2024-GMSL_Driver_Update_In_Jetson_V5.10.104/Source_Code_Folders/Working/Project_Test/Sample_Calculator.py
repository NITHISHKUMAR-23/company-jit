#Sample project for GitLab training
var1 = 13
var2 = 14

print 'addition = ' var1+var2

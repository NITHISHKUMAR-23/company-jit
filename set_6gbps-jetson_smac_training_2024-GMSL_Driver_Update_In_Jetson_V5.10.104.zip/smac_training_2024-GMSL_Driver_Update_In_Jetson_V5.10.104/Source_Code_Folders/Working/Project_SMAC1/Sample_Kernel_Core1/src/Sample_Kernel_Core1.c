/*****************************************************************************
 * Sample_Kernel_Core1.c
 *****************************************************************************/

#include "adi_initialize.h"
#include "Sample_Kernel_Core1.h"

#include <sys/platform.h>
#include <sys/adi_core.h>

/** 
 * If you want to use command program arguments, then place them in the following string. 
 */
char __argv_string[] = "";

int main()
{
	addition();
	lib_main();

	/* Begin adding your custom code here */

	return 0;
}


/*****************************************************************************
 * Sample_Kernel_Core1.h
 *****************************************************************************/

#ifndef __SAMPLE_KERNEL_CORE1_H__
#define __SAMPLE_KERNEL_CORE1_H__

extern int sum;
int num1=5;
int num2=6;
#ifdef ADDITION
void addition(void)
{
	sum=num1+num2;
}
#endif
/* Add your custom header content here */

#endif /* __SAMPLE_KERNEL_CORE1_H__ */

/*****************************************************************************
 * Sample_Kernel_Core2.h
 *****************************************************************************/

#ifndef __SAMPLE_KERNEL_CORE2_H__
#define __SAMPLE_KERNEL_CORE2_H__


/* Add your custom header content here */

#endif /* __SAMPLE_KERNEL_CORE2_H__ */

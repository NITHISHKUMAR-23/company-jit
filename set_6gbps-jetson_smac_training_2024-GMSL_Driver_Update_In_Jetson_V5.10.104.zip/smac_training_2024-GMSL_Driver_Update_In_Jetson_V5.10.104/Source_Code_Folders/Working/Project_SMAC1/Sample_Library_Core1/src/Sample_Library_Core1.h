/*****************************************************************************
 * Sample_Library_Core1.h
 *****************************************************************************/

#ifndef __SAMPLE_LIBRARY_CORE1_H__
#define __SAMPLE_LIBRARY_CORE1_H__

int sum;
/* Add your custom header content here */
int multipilication(int a,int b)
{
	sum=a*b;
	return sum;
}
#endif /* __SAMPLE_LIBRARY_CORE1_H__ */

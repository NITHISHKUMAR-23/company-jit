/*****************************************************************************
 * Sample_Library_Core1.c
 *****************************************************************************/

#include "Sample_Library_Core1.h"
/** 
 * If you want to use command program arguments, then place them in the following string. 
 */
int value[100];
int lib_main()
{
for(int i=0;i<100;i++)
{
	value[i] = multipilication(i,2);

}
}


Baselined code

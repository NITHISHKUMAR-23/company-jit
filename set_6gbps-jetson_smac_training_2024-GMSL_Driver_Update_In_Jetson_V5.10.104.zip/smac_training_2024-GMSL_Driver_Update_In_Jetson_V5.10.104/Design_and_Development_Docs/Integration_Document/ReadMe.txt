Integration document and related details

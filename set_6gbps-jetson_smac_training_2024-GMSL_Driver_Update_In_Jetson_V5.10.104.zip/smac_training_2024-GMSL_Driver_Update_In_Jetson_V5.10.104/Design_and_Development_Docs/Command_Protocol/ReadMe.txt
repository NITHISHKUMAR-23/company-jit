The command protocol document and details

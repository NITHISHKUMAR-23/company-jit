The Technical Specification phase documents ( SRS Document, TS document, TS Checklist, Test Plan) for the specific task

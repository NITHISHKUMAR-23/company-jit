The test plan and related details

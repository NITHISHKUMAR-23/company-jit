API document and related details

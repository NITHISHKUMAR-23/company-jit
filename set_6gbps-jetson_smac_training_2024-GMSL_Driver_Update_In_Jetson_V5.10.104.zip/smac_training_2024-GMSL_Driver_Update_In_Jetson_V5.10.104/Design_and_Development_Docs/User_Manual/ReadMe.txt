User manual and related details

The planning documents and Weekly MOMs

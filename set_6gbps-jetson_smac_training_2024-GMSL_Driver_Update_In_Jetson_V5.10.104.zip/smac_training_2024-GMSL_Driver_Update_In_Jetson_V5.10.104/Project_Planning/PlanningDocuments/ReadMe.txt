The planning documents (TMP, TMP Checklist, PSP, Estimation sheet, Schedule sheet, Stakeholder Matrix, RD Document) for the specific task

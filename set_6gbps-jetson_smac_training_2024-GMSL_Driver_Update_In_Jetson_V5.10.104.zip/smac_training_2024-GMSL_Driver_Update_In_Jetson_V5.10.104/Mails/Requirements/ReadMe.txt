The mails related to requirements discussion, freezing requirements

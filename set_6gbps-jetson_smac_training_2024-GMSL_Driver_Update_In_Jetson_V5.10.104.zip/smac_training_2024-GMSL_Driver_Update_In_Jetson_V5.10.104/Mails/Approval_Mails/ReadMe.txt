 Approval mails from Customer, SM, PM related to all phases of the project

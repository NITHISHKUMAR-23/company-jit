import yaml
import json

def command_validation(command,parameter,parameter_no,dictionary,path,file_format):

    if file_format == 1:
        with open(path, "r") as file:
            dict = json.load(file)
    elif file_format == 0:
        with open(path, "r") as file:
            dict = yaml.safe_load(file)

    if command in dict:
        return (dict[command]["name"], json.dumps(dict[command]), len(dict[command]["parameters"]))  # Convert dictionary to JSON strin
    else:
        return "i"
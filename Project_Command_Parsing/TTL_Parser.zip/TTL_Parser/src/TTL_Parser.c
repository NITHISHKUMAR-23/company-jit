#include "TTL_Parser.h"

int main()
{
    char Full_command[15];
    char path[256];
    int reference_file_type = 0;
    if(reference_file_type == 0)
    strcpy(path,"D:\\smac_training_2024\\Source_Code_Folders\\Working\\TTL_Parser\\Input_Files\\Command_Reference_JSON.json");
    else
    strcpy(path,"D:\\smac_training_2024\\Source_Code_Folders\\Working\\TTL_Parser\\Input_Files\\Command_Reference_YAML.yaml");

    strcpy(Full_command,"0x20000033");

    char* command_string = command_identification(Full_command,path,reference_file_type);
    // printf("%s\n",command_string);
    // printf("%d\n",parser.parameter_count);
    // printf("%s",parser.Dict);
}

char* command_identification(char* command,char*path,int file_format)
{
    char* str = c_to_python_call("command_validation",command,false,false,"false",path,file_format);
    // printf("%s\n",str);
    return str;
}

char* c_to_python_call(char* function_name,char* command,int parameter,int parameter_no,char* dictionary,char* path, int reference_file_type) 
{
    // Initialize the Python interpreter
    Py_Initialize();

    // Import the Python script
    PyObject *pName = PyUnicode_FromString("TTL_Parser");  // Python module name
    PyObject *pModule = PyImport_Import(pName);
    Py_DECREF(pName);

    if (pModule != NULL) {
        // Get the function from the Python script
        PyObject *pFunc = PyObject_GetAttrString(pModule, function_name);

        if (pFunc && PyCallable_Check(pFunc)) {
            // Call the Python function and get the result (JSON string)   
            PyObject *pArg = PyTuple_Pack(6, 
                PyUnicode_FromString(command),
                PyLong_FromLong(parameter),
                PyLong_FromLong(parameter_no),
                PyUnicode_FromString(dictionary),
                PyUnicode_FromString(path),
                PyLong_FromLong(reference_file_type)
            );

            PyObject *pValue = PyObject_CallObject(pFunc, pArg);

            if (pValue != NULL) {
                // Return the JSON string
                Py_XDECREF(pFunc);
                Py_DECREF(pModule);

                parser.parameter_count = PyLong_AsLong(PyTuple_GetItem(pValue, 2));
                parser.Dict = (char*)PyUnicode_AsUTF8(PyTuple_GetItem(pValue, 1));
                return (char*)PyUnicode_AsUTF8(PyTuple_GetItem(pValue, 0));
                // return pValue; // Return JSON string
            } else {
                PyErr_Print();
                fprintf(stderr, "Failed to call Python function '%s'.\n",function_name);
            }
        } else {
            if (PyErr_Occurred())
                PyErr_Print();
            fprintf(stderr, "Cannot find function '%s'.\n",function_name);
        }

        Py_XDECREF(pFunc);
        Py_DECREF(pModule);
    } else {
        PyErr_Print();
        fprintf(stderr, "Failed to load 'parser' module.\n");
    }

    // Finalize the Python interpreter
    Py_Finalize();
    return NULL;
}
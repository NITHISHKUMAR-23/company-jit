#include <python3.11/Python.h>
#include <stdio.h>
#include <stdbool.h>

char* command_identification(char*,char*,int);
char* c_to_python_call(char*,char*,int,int,char*,char*,int);

typedef struct 
{
    int parameter_count;
    char* Dict;
}Python_return_values;

Python_return_values parser;
import sys
import yaml

# Function to load a YAML file
def load_yaml(file_path):
    with open(file_path, 'r') as file:
        data = yaml.safe_load(file)
        return data

def check_parameter1(Command, Parameter, start, end, value):
    # Global variable for the YAML content
    global yaml_content

    # Assuming yaml_content is loaded with the YAML file
    parameters_map = yaml_content[f'Command_0x{Command:X}']
    parameter_bits = parameters_map[f'Parameter{Parameter}']['Bits']
    bit_range_key = f'bit{start}-{end}'
    if bit_range_key in parameter_bits:
        description = parameter_bits[bit_range_key]
        if isinstance(description, dict):
            if value in description:
                print(f"Value '{value}' enables: {description[value]}")
            else:
                print(f"Value '{value}' is not valid for bit range {bit_range_key}.")
                print("Valid values are:")
                for valid_value, meaning in description.items():
                    print(f"  {valid_value}: {meaning}")
        else:
            print(f"Bit range {bit_range_key} description: {description}")
    else:
        print(f"Bit range {bit_range_key} is not defined in Parameter{Parameter}.")

def main():
    # Path to the YAML file
    yaml_file = 'example.yaml'

    # Load the YAML content
    global yaml_content
    yaml_content = load_yaml(yaml_file)

    # Parse command-line arguments
    if len(sys.argv) != 6:
        print("Usage: python yaml_access.py <Command> <Parameter> <start> <end> <value>")
        sys.exit(1)

    Command = int(sys.argv[1], 16)  # Hexadecimal command
    Parameter = int(sys.argv[2])
    start = int(sys.argv[3])
    end = int(sys.argv[4])
    value = sys.argv[5]

    # Check the parameter
    check_parameter1(Command, Parameter, start, end, value)

if __name__ == "__main__":
    main()

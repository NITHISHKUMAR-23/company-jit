//Include all the libraries, macros, function prototypes here
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>

#define MAX_PARAMETERS_COUNT 16
#define MAX_HEX_LENGTH 11
#define SUCCESS 1
#define FAILURE 0
#define UNDEFINED 2


uint16_t Parameter_buffer[MAX_PARAMETERS_COUNT];
uint8_t Parameter_count = 0;
char Full_command[MAX_HEX_LENGTH] = "\0";
char *send_command;
FILE*cp;
int32_t command_Validation(void);
int parameter_parsing(uint16_t ,int32_t);


//Include all global declarations here
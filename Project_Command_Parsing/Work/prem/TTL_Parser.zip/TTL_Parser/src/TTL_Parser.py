import sys
import json
import yaml
 
# Function to parse the file data based on the command
def parse_json_command(command, parameter, data):
    parameter_count=0
    if command in data:
        parameter_count=len(data[command]["parameters"])
        print(parameter_count)
        print(data[command]["name"])
        sys.exit(1)
    else:
        print(parameter_count)
        sys.exit(1)
        
# Function to process parameters
def parameter_parsing(command_name,parameter_value,data,parameter_num):
    # print(data)
    val=0
   
def main():
    # Check if the required arguments are passed
    if len(sys.argv) < 4:
        print("Usage: python parser.py <command_name> <parameter> <parameter_number>")
        sys.exit(1)
 
    # Arguments passed from the command line
    command_name = sys.argv[1]
    parameter_value = sys.argv[2]
    parameter_no =sys.argv[3]
 
    # Path to your JSON file
    
    # file_path = "D:\\smac_training_2024\\Source_Code_Folders\\Working\\TTL_Parser\\Input_Files\\Command_Reference_JSON.json"  # Update this path accordingly
    file_path = "D:\\smac_training_2024\\Source_Code_Folders\\Working\\TTL_Parser\\Input_Files\\Command_Reference_YAML.yaml"  # Update this path accordingly
 
    if "yaml" in file_path:
        try:
            # Load JSON file
            with open(file_path, 'r') as json_file:
                data = yaml.safe_load(json_file)
        except Exception as e:
            print(f"Error reading the JSON file: {e}")
            sys.exit(1)
    else:
        try:
            # Load JSON file
            with open(file_path, 'r') as json_file:
                data = json.load(json_file)
        except Exception as e:
            print(f"Error reading the JSON file: {e}")
            sys.exit(1)
 
    
    # Call the function to parse the JSON and process the command
    if parameter_value == "false":
        parse_json_command(command_name, parameter_value, data)
    else:
        parameter_num = "parameter"+parameter_no
        parameter_parsing(command_name,parameter_value,data[command_name],parameter_num)
       

if __name__ == "__main__":
    main()
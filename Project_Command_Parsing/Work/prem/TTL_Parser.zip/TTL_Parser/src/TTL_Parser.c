#include "TTL_Parser.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
 

void main()
{

    strcpy(Full_command,"0x20000030");
    Parameter_buffer[0] = (uint16_t)0x2336;
    Parameter_buffer[1] = (uint16_t)0x2336;
    char output[1024];
    FILE *fp = fopen("D:\\smac_training_2024\\Source_Code_Folders\\Working\\TTL_Parser\\src\\output.txt","w");

    if(command_Validation() == FAILURE)
    {
        fprintf(fp,"%s is an Invalid Command\n",Full_command);
        printf("Invalid Command\n");
        return;
    }
   
    while (fgets(output, sizeof(output), cp) != NULL) 
    {
    //    printf("%s",output);
       fprintf(fp,"%s", output);// command name will be print here
    }
    fclose(cp);
 
   
    for(int32_t parameter_no = 1; parameter_no <= Parameter_count; parameter_no++)
    {
        if(parameter_parsing(Parameter_buffer[parameter_no - 1],parameter_no) == FAILURE)
        {
            return;
        }
        while (fgets(output, sizeof(output), cp) != NULL)
        {
            // printf("%s",output);
            fprintf(fp,"%s", output); // remaining output 
        }
        fclose(cp);
    }
    
 
}

// Function to validate the command using a Python script
int command_Validation(void)
{
    char bit_field_command[512];
    snprintf(bit_field_command, sizeof(bit_field_command), 
    "python D:\\smac_training_2024\\Source_Code_Folders\\Working\\TTL_Parser\\src\\TTL_Parser.py %s %s %s",Full_command,"false","false");
    cp=popen(bit_field_command,"r");
    if(cp==NULL)
    {
        printf("error opening python file\\Invalid file path ");
    }

    char validate[5];
    fgets(validate, sizeof(validate), cp);
    Parameter_count=atoi(validate);

    if((Parameter_count) == 0)
    {
        return FAILURE;
    }
    // printf("%d\n",Parameter_count);
    return SUCCESS;
}

// Function to parse each parameter using the Python script
int parameter_parsing(uint16_t parameter, int parameter_no)
{
    char bit_field_command[512];
    snprintf(bit_field_command, sizeof(bit_field_command),
    "python D:\\smac_training_2024\\Source_Code_Folders\\Working\\TTL_Parser\\src\\TTL_Parser.py %s %d %d",Full_command,parameter,parameter_no);
    cp=popen(bit_field_command,"r");
    
    if(cp == NULL)
    {
        printf("error opening python file\\Invalid file path ");
        return FAILURE;
    }

    return SUCCESS;
}
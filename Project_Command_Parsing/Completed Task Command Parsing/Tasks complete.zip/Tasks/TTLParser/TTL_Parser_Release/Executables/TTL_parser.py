#*****************************************************************************
#  Project          :   TTl Parser
#  Organization  :  	Jasmin Infotech Private Limited, Chennai
#  File Name        :   TTL_Parser.py
#  Description      :   This module extracts and processes TTL command details from a reference file in either JSON or YAML format.
#                       It parses the provided TTL command and its parameters, checks for bitfield information, and formats the output.
#                       Errors in file loading, command validation, or parameter processing are also handled, with descriptive error messages.
#                       The file includes functions for extracting bitfield names and values from the reference data.
#
#*****************************************************************************/ 

import json
import yaml

#******************************************************************************************************************************************
#  Module Name        : extract_ttl_details
#  Functionality      : This module extracts details from a reference file (in JSON or YAML format) based on the provided TTL 
#                       command and associated parameters. It parses the input TTL command, retrieves related information from 
#                       the reference file, and validates parameters. It also processes the bitfields associated with the 
#                       parameters and formats the results into a structured output string.
#  Input Parameters   :
#                       - Full_command (str) : The full TTL command to look up in the reference file.
#                       - Parameter_buffer (list) : List of parameter values to be processed.
#                       - Reference_File_Path (str) : Path to the reference JSON or YAML file.
#                       - reference_file_type (int) : Type of the reference file (1 for JSON, 0 for YAML).
#                       - Current_Parameter_count (int) : The total number of parameters in the current TTL command.
#  Output Parameters  : 
#                       - Returns (str) : 
#                         - Formatted string detailing the command, parameters, and bitfields.
#                         - Error messages if there are issues with file loading, command validation, or parameter processing.
#******************************************************************************************************************************************

def extract_ttl_details(Full_command, Parameter_buffer, Reference_File_Path, reference_file_type, Current_Parameter_count):
    
    try:
        with open(Reference_File_Path, "r") as file:
            if reference_file_type == ".json":
                values = json.load(file)  # Load JSON file
            elif reference_file_type in [".yaml", ".yml"]:
                values = yaml.safe_load(file)  # Load YAML file
            else:
                print("Invalid reference file type")  # Handle unsupported file type
            
    except (FileNotFoundError, ValueError, yaml.YAMLError, json.JSONDecodeError) as e:
        print( f"Error loading reference file: {e}" ) # Handle file loading errors

    if Full_command in values:
        command_dict = values.get(Full_command)  # Get the command details if present
    else:
       print("Invalid dictionary")  # Command not found in the dictionary

    result = "\t" * 8 + command_dict.get("name") + "(" + Full_command + ")"  # Format command name

    try:
        Command_Parameter_count = len(command_dict.get("parameters"))  # Get the number of parameters for the command
      
    except TypeError:
        return "\t" * 8 + command_dict.get("name") + "(" + Full_command + ")"  # Handle missing parameters

    # Determine the starting index for processing based on parameter count
    if (Current_Parameter_count - Command_Parameter_count) >= 0:
        i = Current_Parameter_count - Command_Parameter_count
    else:
        i = 0

    # Loop through the parameters to process each one
    for i in range(i, Current_Parameter_count):
        if Parameter_buffer[i] != 0:  # Check if the parameter is non-zero
            try:
                parameter_Number = int((Parameter_buffer[i] & 0x00FF0000) >> 16)  # Extract parameter number
                accessed_parameter = f"parameter{str(parameter_Number)}"  # Format the parameter name
                parameter = f"{'Parameter number'} : {str(parameter_Number)}"  # Display parameter number
                result += "\n" + parameter + "\n" + "\n"

                if accessed_parameter not in command_dict.get("parameters"):  # Validate if the parameter exists
                    print(f"{accessed_parameter} not found")

                accessed_param = command_dict["parameters"][accessed_parameter]  # Access parameter details

                # Check if the parameter contains bitfields and process them
                if isinstance(accessed_param, dict) and "bitfields" in accessed_param:
                    for bitfield, bitfield_data in accessed_param["bitfields"].items():
                        # Handle bitfields with ranges (e.g., 15-10)
                        if '-' in bitfield:
                            start, end = map(int, bitfield.split('-'))
                            mask = (1 << (start - end + 1)) - 1
                            extracted_bits_int = (Parameter_buffer[i] >> end) & mask  # Extract bitfield value
                            extracted_bits_bin = bin(extracted_bits_int)[2:].zfill(start - end + 1)  # Format extracted bits
                            temp = bitfieldNameAndValue(command_dict, accessed_parameter, bitfield, extracted_bits_bin)
                            if temp:
                                result += temp + "\n"
                        else:
                            # Handle single bitfields
                            extracted_bits_bin = (Parameter_buffer[i] >> int(bitfield)) & 1
                            temp = bitfieldNameAndValue(command_dict, accessed_parameter, bitfield, extracted_bits_bin)
                            if temp:
                                result += temp + "\n"
                else:
                    print( f"Error: {accessed_parameter} is not a dictionary or missing 'bitfields'.\n" ) # Missing or invalid bitfields
            except KeyError as e:
                print( f"Error: Missing expected key in JSON data: {e}\n" ) # Handle missing key in data
            except ValueError as e:
                print("Error: Invalid value encountered. Ensure parameter values are in correct format. {e}\n" ) # Handle invalid values

    return result  # Return the formatted result


#******************************************************************************************************************************************
#  Module Name        : bitfieldNameAndValue
#  Functionality      : This module processes individual bitfields for parameters. It retrieves the bitfield description and 
#                       value from the reference data based on the bitfield and parameter number. If the bitfield is 
#                       correctly defined, it formats the description and value of the bitfield into a readable format.
#  Input Parameters   :
#                       - data (dict) : The parsed reference data containing parameters and bitfields.
#                       - parameter_input (str) : The name of the parameter being processed.
#                       - bitfield (str) : The bitfield to be processed.
#                       - bit_value (str) : The value of the bitfield to be used for description lookup.
#  Output Parameters  : 
#                       - Returns (str) : 
#                         - Formatted bitfield description if valid data is found.
#                         - Error message if any issue is encountered (missing parameter, bitfield, or value).
#******************************************************************************************************************************************

def bitfieldNameAndValue(data, parameter_input, bitfield, bit_value):
    bit_value = str(bit_value)
    parameter_data = data.get("parameters").get(parameter_input)    # Access the parameter data

    if not parameter_data:
        print( f"Error: '{parameter_input}' not found.") # Return error if parameter is missing
        return None 

    bitfield_data = parameter_data.get("bitfields").get(bitfield) or parameter_data.get("Bitfields").get(bitfield) or parameter_data.get("BITFIELDS").get(bitfield)  # Access the bitfield data
    if not bitfield_data:
        print (f"Error: '{bitfield}' not found in '{parameter_input}'.") # Return error if bitfield is missing
        return None 

    field_name = bitfield_data.get("name")   # Get the name of the bitfield
    if field_name == "Reserved":
        return None     # If the bitfield is reserved, return None

    values = bitfield_data.get("values") or bitfield_data.get("Values") or bitfield_data.get("VALUES")
    value_description = values.get(bit_value, values.get("default"))   # Get description of the bitfield value

    if not value_description:
        print( f"Error: Bit value '{bit_value}' not found for bitfield '{bitfield}'.")
        return None 

    return f"-> {field_name:<41} : {value_description}" # Format the result string

#include "TTL_parser.h"

/******************************************************************************************************************************************
 *  Project          :   TTL Parser
 *  Organization     :   Jasmin Infotech Private Limited, Chennai
 *  File Name        :   TTL_parser.c
 *  Description      :   This file implements various functions for parsing TTL commands, interacting with Python scripts,
 *                       validating commands, and managing file metadata. It establishes communication between C and Python for
 *                       executing specific commands and handles the extraction and processing of hexadecimal data from TTL input.
 *                       Functions are provided for managing command buffers, writing output, and handling file metadata.
 ******************************************************************************************************************************************/

/******************************************************************************************************************************************
 *  Module Name        : c_to_python_call
 *  Functionality      : Establishes a communication bridge between the C program and a Python script. It initializes the Python
 *                       interpreter, imports a Python module, and invokes a specified Python function. This function passes parameters
 *                       (command, parameter list, file path, and file type) from the C code to the Python script and retrieves the result.
 *  Input Parameters   :
 *                       - function_name (char*)          : The name of the Python function to invoke.
 *                       - command (char*)                : Command string to be processed by the Python function.
 *                       - parameter_buffer (uint32_t[])  : Array of integers representing parameters to pass to the Python function.
 *                       - path (char*)                   : File path (JSON/YAML) to be used by the Python function.
 *                       - reference_file_type (uint8_t) : Indicator of the reference file type (JSON/YAML).
 *                       - current_parameter_count (uint32_t)  : Number of parameters in `parameter_buffer`.
 *  Output Parameters  :
 *                       - Returns a JSON string (uint8_t*) containing the result of the Python function.
 ******************************************************************************************************************************************/

uint8_t *c_to_python_call(uint8_t *function_name, uint8_t *command, uint32_t parameter_buffer[], uint8_t *path, const uint8_t  *reference_file_type, uint32_t current_parameter_count)
{
    Py_Initialize();
    PyObject *pName = PyUnicode_FromString("TTL_parser");
    PyObject *pModule = PyImport_Import(pName);
    Py_DECREF(pName);

    if (pModule != NULL)
    {
        // Get the function from the Python script
        PyObject *pFunc = PyObject_GetAttrString(pModule, function_name);

        if (pFunc && PyCallable_Check(pFunc))
        {
            // Call the Python function and get the result (JSON string)
            PyObject *py_list = PyList_New(current_parameter_count);
            if (py_list == NULL)
            {
                PyErr_PrintEx(1);
                return NULL;
            }
            // Populate the Python list with integers from parameter_buffer
            for (uint32_t i = 0; i < current_parameter_count; ++i)
            {
                PyObject *py_int = PyLong_FromLong(parameter_buffer[i]);
                if (py_int == NULL)
                {
                    PyErr_PrintEx(1);
                    Py_XDECREF(py_list);
                    return NULL;
                }
                PyList_SetItem(py_list, i, py_int); // PyList_SetItem steals the reference
            }
            PyObject *pArg = PyTuple_Pack(5,
                                          PyUnicode_FromString(command),
                                          py_list,
                                          PyUnicode_FromString(path),
                                          PyUnicode_FromString(reference_file_type),
                                          PyLong_FromLong(current_parameter_count));

            PyObject *pValue = PyObject_CallObject(pFunc, pArg);

            // Handle the return value
            if (pValue != NULL)
            {
                // If the result is a string, convert it to a C string
                uint8_t *result = (uint8_t *)PyUnicode_AsUTF8(pValue);
                if (result != NULL)
                {

                    return result;
                }
                else
                {
                    PyErr_Print();
                }
            }
            // Clean up
            Py_XDECREF(pValue);
        }

        else
        {
            if (PyErr_Occurred())
                PyErr_PrintEx(1);
            fprintf(stderr, "Cannot find function '%s'.\n", function_name);
        }

        Py_XDECREF(pFunc);
        Py_DECREF(pModule);
    }
    else
    {
        PyErr_PrintEx(1);
        fprintf(stderr, "Failed to load 'parser' module.\n");
    }

    // Finalize the Python interpreter
    Py_Finalize();
    return NULL;
}

/******************************************************************************************************************************************
 *  Module Name        : check_command
 *  Functionality      : Validates the input TTL value to check if it is a command or parameter. If valid, the function updates buffers
 *                       accordingly.
 *  Input Parameters   :
 *                       - ttl_value (uint32_t) : The hexadecimal TTL value to validate.
 *  Output Parameters  :
 *                       - Returns `SUCCESS`, `FAILURE`, or `INVALID` to indicate the validation result.
 ******************************************************************************************************************************************/

uint32_t check_command(uint32_t ttl_value)
{
    if (((ttl_value >> CHECK_28_31_BIT) & BIT_ACCESS_4) != VALID_COMMAND_OR_PARAM)
    {
        // Invalid command, set parameter buffer to 0 and return UNDEFINED

        parameter_buffer[parameter_count++] = (uint32_t)(0);
        return INVALID;
    }

    uint32_t check_cmd_or_param = (ttl_value >> CHECK_16_23_BIT) & BIT_ACCESS_8;

    if (check_cmd_or_param == 0)
    {
        // Store the command in full_command and reset the parameter count
        uint8_t hex_string[MAX_HEX_LENGTH];
        sprintf(hex_string, "%X", ttl_value);
        strcat(full_command, hex_string);
        current_parameter_count = parameter_count;

        // for(int i=0;i< current_parameter_count;i++){
        // printf("%d\n",parameter_buffer[i]);}

        parameter_count = 0;
        return SUCCESS;
    }
    else if ((check_cmd_or_param > 0) || (check_cmd_or_param > 0)) // If the value is between 1 and 15, it's a parameter
    {
        // If it's a parameter, store it in the parameter buffer
        parameter_buffer[parameter_count++] = ttl_value;
        return FAILURE; // Valid parameter
    }
    else // Invalid value for command/parameter
    {
        // Reset parameter buffer and return UNDEFINED
        parameter_buffer[parameter_count++] = (uint32_t)(0);
        return INVALID;
    }
    return FAILURE;
}

/******************************************************************************************************************************************
 *  Module Name        : InitializeMetaData
 *  Functionality      : Writes metadata information to the output file, such as the TTL file name, current time, date, and author.
 *  Input Parameters   :
 *                       - TTL_file (char*) : Name of the TTL input file.
 *                       - now (time_t)     : Current time as a `time_t` object.
 *                       - day (char*)      : Formatted string to store date and time.
 *                       - author (char*)   : Name of the author.
 ******************************************************************************************************************************************/

void InitializeMetaData(char *TTL_file, time_t now, char *day, char *author)
{

    fprintf(output_file, "Given TTL file : TTL_Input_file");
    time(&now);
    strftime(day, MAX_BUFFER_LENGTH, "\t\tTime : %H:%M:%S \t\t Date : %d-%m-%Y", localtime(&now));
    fprintf(output_file, "%s\n", day);
    fprintf(output_file, "Author : %s\n", author);
    fprintf(output_file, "\n");
}

/******************************************************************************************************************************************
 *  Module Name        : extract_hex
 *  Functionality      : Extracts hexadecimal data from a TTL command string. Validates if the extracted data is a valid hexadecimal
 *                       value.
 *  Input Parameters   :
 *                       - ttl_data (uint8_t*) : A string containing TTL command data.
 *  Output Parameters  :
 *                       - Returns a valid hexadecimal value, or `INVALID` if validation fails.
 ******************************************************************************************************************************************/

uint32_t extract_hex(uint8_t *ttl_data)
{
    uint8_t ttl_data_copy[strlen(ttl_data) + 1];

    strcpy(ttl_data_copy, ttl_data);

    uint8_t *command = strtok(ttl_data_copy, "xX");
    if (strncmp(strlwr(command), "sendln '0", FULL_COMMAND_LENGTH) == 0)
    {
        uint8_t *str = strtok(NULL, "'");

        if (strlen(str) == MAX_HEX_LENGTH)
        {
            for (uint32_t i = 0; i < MAX_HEX_LENGTH; i++)
            {
                if (!isxdigit(str[i]))
                {
                    parameter_buffer[parameter_count++] = (uint32_t)(0);
                    return INVALID;
                }
            }
            uint32_t return_data = strtoul(str, NULL, HEX_BASE);
            return return_data;
        }
        else
        {
            parameter_buffer[parameter_count++] = (uint32_t)(0);
            return INVALID;
        }
    }

    return MPAUSE_SKIP;
}

/******************************************************************************************************************************************
 *  Module Name        : double_long_line
 *  Functionality      : Writes a horizontal divider line (repeating `=` characters) to the output file.
 *  Input Parameters   :
 *                       - output_file (FILE*) : File pointer to write the divider line.
 *                       - size (uint8_t)      : Length of the divider line.
 ******************************************************************************************************************************************/

void double_long_line(FILE *output_file, uint8_t size)
{
    for (uint32_t i = 0; i < size; i++)
    {
        fputc('=', output_file);
    }
    fputc('\n', output_file);
}

/******************************************************************************************************************************************
 *  Module Name        : write_ttl_info
 *  Functionality      : Writes TTL command results to the output file, including a horizontal divider line after the content.
 *  Input Parameters   :
 *                       - output_file (FILE*) : File pointer for writing the results.
 *                       - line_length (int8_t): Length of the horizontal divider line.
 *                       - Command_result (uint8_t*) : The TTL command result to write.
 *  Output Parameters  :
 *                       - Returns `SUCCESS` or `FAILURE` to indicate the status of the operation.
 ******************************************************************************************************************************************/

uint8_t write_ttl_info(FILE *output_file, int8_t line_length, uint8_t *Command_result)
{
    if (Command_result != NULL && output_file != NULL)
    {
        fprintf(output_file, "%s\n", Command_result);
        double_long_line(output_file, line_length);
        return SUCCESS;
    }
    else
    {
        fprintf(stderr, "Failed to write the ttl information\n");
        return FAILURE;
    }
}

/******************************************************************************************************************************************
 *  Module Name        : main
 *  Functionality      : The entry point for the TTL Parser program. Parses TTL input file, validates commands, communicates with Python
 *                       scripts, and generates an output file with results and metadata.
 *  Input Parameters   :
 *                       - argc (int)       : Argument count from the command line.
 *                       - argv (char*[])   : Argument values from the command line, including file paths.
 *  Output Parameters  :
 *                       - Returns `EXIT_SUCCESS` or `EXIT_FAILURE` to indicate program status.
 ******************************************************************************************************************************************/

uint32_t main(uint32_t argc, char *argv[])
{

    time_t now;
    now = 0;
    char day[MAX_BUFFER_LENGTH];
    uint8_t current_line = 0u;
    uint8_t print_line_length = 100u;
    char *username = getenv("USER");
    if (username == NULL)
    {
        username = getenv("USERNAME");
    }
    if (argc != ARGUMENT_SIZE)
    {
        fprintf(stderr, "Usage: %s <TTL_File> <Reference_File> <OUT_File> \n", argv[0]);
        return EXIT_FAILURE;
    }

    // Get file paths from the command line arguments
    TTL_File = argv[1];            // Input TTL File Path
    Reference_File_Path = argv[2]; // Reference JSON Path
    OUT_File = argv[3];            // Output Text File Path

    reference_file_type = strrchr(Reference_File_Path, '.'); // Find last occurrence of '.'
    

    if (reference_file_type != NULL)
    {   
        if (((strcmp(reference_file_type, ".json")) != 0 && (strcmp(reference_file_type, ".yaml")) != 0 && (strcmp(reference_file_type, ".yml") != 0 ) ))
        {
            fprintf(stderr, "Error: Both files must be either .json or .yaml/.yml\n");
            return EXIT_FAILURE;
        }
     
    }
    else
    {
        fprintf(stderr, "Error: There is no any file extension for the reference file\n");
        return EXIT_FAILURE;
    }

    input_file = fopen(TTL_File, "r");
    if (input_file == NULL)
    {
        fprintf(stderr, "Input file is not open\n");
        fclose(input_file);
        return EXIT_FAILURE;
    }
    fseek(input_file, 0, SEEK_END);
    long file_size = ftell(input_file); // Get the size of the file
    // If the file size is zero, the file is empty
    if (file_size == 0)
    {
        fprintf(stderr, "Input file is empty\n");
        fclose(input_file);
        return EXIT_FAILURE;
    }
    fseek(input_file, 0, SEEK_SET); // Assign the File Pointer to start.
    output_file = fopen(OUT_File, "w");
    if (output_file == NULL)
    {
        fprintf(stderr, "Output_file is not open\n");
        fclose(output_file);
        return EXIT_FAILURE;
    }
    InitializeMetaData(TTL_File, now, day, username);

    char line[MAX_BUFFER_LENGTH];
    double_long_line(output_file, print_line_length);
    while (fgets(line, sizeof(line), input_file) != NULL)
    {
        int Hex_Data = extract_hex(line);
        if ((Hex_Data != INVALID) && (Hex_Data != MPAUSE_SKIP))
        {

            strcpy(full_command, "0x");

            int status = check_command(Hex_Data);

            if (status == SUCCESS)
            {
                char *Command_result = (char *)c_to_python_call("extract_ttl_details", full_command, parameter_buffer, Reference_File_Path, reference_file_type, current_parameter_count);
                uint8_t written_status = write_ttl_info(output_file, print_line_length, Command_result);
                if (written_status == FAILURE)
                {
                    fprintf(stderr, "No return for command %s\n", full_command);
                }
            }
            else if (status == INVALID)
            {
                fprintf(stderr, "Invalid value for command/parameter\n");
            }
        }
        else if (Hex_Data != MPAUSE_SKIP)
        {
            fprintf(stderr, "Invalid hex value\n");
        }
    }

    fclose(input_file);
    fclose(output_file);
    printf("Output_file is successfully Generated");
    return SUCCESS;
}
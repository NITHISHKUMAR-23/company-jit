/******************************************************************************************************************************************
*  Project          :   TTL Parser
*  Organization     :   Jasmin Infotech Private Limited, Chennai
*  File Name        :   TTL_Parser.h
*  Description      :   This header file contains all necessary macro definitions, enum declarations, and function prototypes 
*                       for the TTL Parser project. It defines the data structures and functions required for parsing TTL 
*                       commands, validating inputs, extracting data, interacting with Python scripts, and managing file metadata.
*                       The corresponding implementation is provided in the TTL_Parser.c file.
******************************************************************************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stdint.h>
#include <ctype.h>
#include <stdarg.h>
#include <python3.11/Python.h>  // Include the Python API for C (Python 3.11)
#include <time.h>

#define PATH_SIZE 256
#define MAX_BUFFER_LENGTH 40
#define MAX_HEX_LENGTH 8
#define FULL_COMMAND_LENGTH 11
#define CMNT_SLASH_SIZE 2
#define TTL_DATA_SIZE 256
#define DATE_BUFFER_SIZE 100
#define ARGUMENT_SIZE 4
#define HEX_BASE 16
#define CHECK_28_31_BIT 28
#define CHECK_16_23_BIT 16
#define BIT_ACCESS_8 255
#define BIT_ACCESS_4 127
#define VALID_COMMAND_OR_PARAM 2
#define FILE_EXTENSION_SIZE 6

const uint8_t  * reference_file_type;
uint32_t parameter_buffer[MAX_BUFFER_LENGTH]={0};
uint8_t parameter_count = 0;
uint32_t current_parameter_count = 0;
char full_command[FULL_COMMAND_LENGTH];

enum status
{
    SUCCESS,
    FAILURE,
    INVALID,
    MPAUSE_SKIP
};


FILE *input_file;
FILE *output_file;

char *TTL_File;
char *OUT_File;
char *Reference_File_Path;

//Function Declarations

uint8_t *c_to_python_call(uint8_t *, uint8_t *, uint32_t [], uint8_t *,  const uint8_t  *, uint32_t );
uint32_t check_command(uint32_t);
void double_long_line(FILE *, uint8_t );
uint32_t file_handle_init_meta_data(FILE *, FILE *, uint8_t *, const uint8_t *, time_t , uint8_t *, const uint8_t *, uint8_t , const uint8_t *);
uint32_t extract_hex(uint8_t *);
uint8_t write_ttl_info(FILE *, int8_t , uint8_t *);



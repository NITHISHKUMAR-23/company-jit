#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() 
{
    // Parameters to pass to the Python script
    const char *command_name = "Special_Commands";  // Example command name
    const char *parameter_number = "parameter1";
    
    char bit_field_command[512];
    snprintf(bit_field_command, sizeof(bit_field_command), "python3 D:\\C-practice\\c_json_py\\bitfields.py %s %s ", command_name,parameter_number);

    FILE *fpp = popen(bit_field_command, "r");
    FILE *fw = fopen("D:\\C-practice\\c_json_py\\output.txt", "w");

    if (fpp == NULL) {
        perror("Failed to run Python script");
        return EXIT_FAILURE;
    }
    char bitfields[512];

    while (fgets(bitfields, sizeof(bitfields), fpp) != NULL) {
    //    printf("%s",bitfields);

        int i;
        for(i=0;bitfields[i]!='\n';i++);
        bitfields[i]='\0';
  
    const char *value_to_find = "10";       // Example value to search for

    // Construct the command string with the arguments
    char command[512];
    snprintf(command, sizeof(command), "python3 D:\\C-practice\\c_json_py\\parser.py %s %s %s %s", command_name, bitfields, value_to_find,parameter_number);

    // Open a pipe to the Python script and pass the arguments
    FILE *fp = popen(command, "r");
    if (fp == NULL) {
        perror("Failed to run Python script");
        return EXIT_FAILURE;
    }
    
    // Read and display the output from the Python script
    char output[1024];
    if (fw == NULL) {
        perror("Failed to run Python script");
        return EXIT_FAILURE;
    }

    while (fgets(output, sizeof(output), fp) != NULL) {
       printf("%s",output);
       fprintf(fw,"%s", output);
   
    }
    fclose(fp);

    }
    // Close the file pointer
    fclose(fpp);
    fclose(fw);

    return 0;
}

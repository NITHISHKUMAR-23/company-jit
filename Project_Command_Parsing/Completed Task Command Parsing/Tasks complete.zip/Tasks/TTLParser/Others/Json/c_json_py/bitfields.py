import sys
import json

# Check if the required arguments are passed
if len(sys.argv) < 2:
    print("Usage: python search_json.py <command_name> <parameter_number>")
    sys.exit(1)

# Arguments passed from C program
command_name = sys.argv[1]
parameter_no = sys.argv[2]
# command_name = "Special_Commands"
# parameter_no = "parameter1"

# Load the JSON data (in real use case, load it from a file)
json_file_path = "D:\\C-practice\\c_json_py\\ttl.json"  # Replace with your JSON file path
try:
    with open(json_file_path, 'r') as json_file:
        data = json.load(json_file)
except Exception as e:
    print(f"Error reading the JSON file: {e}")
    sys.exit(1)

# Extract the command section
command_section = data.get("32", {})
# print(command_section)
if command_name != command_section["name"]:
    print(f"Command '{command_name}' not found.")
    sys.exit(1)

# Access the bitfields
bitfields = command_section.get("parameters", {}).get(parameter_no, {}).get("bitfields", {})


for key in bitfields.keys():
    print(key)


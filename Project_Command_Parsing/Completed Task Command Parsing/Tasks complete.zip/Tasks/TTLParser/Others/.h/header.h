#include <stdio.h>
#include <stdint.h>

// Define macros for bit positions
#define DAP_TUNING_MASK 0x30 // Mask for DAP_Tuning (bits 5-4)
#define TX_CHANNEL_MASK 0x0C // Mask for TX Channel Select (bits 3-2)
#define CIDK_PP_MASK 0x02    // Mask for CIDK_PP Enable (bit 1)
#define CIDK_DEC_MASK 0x01   // Mask for CIDK_DEC Enable (bit 0)

// Define possible values for DAP_Tuning (bits 5-4)
#define DAP_TUNING_NONE 0x00
#define DAP_TUNING_FILE1 0x10
#define DAP_TUNING_FILE2 0x20
#define DAP_TUNING_FILE3 0x30

// Define possible values for TX Channel Select (bits 3-2)
#define TX_CHANNEL_1_16 0x00
#define TX_CHANNEL_17_32 0x04

// Define possible values for CIDK_PP Enable (bit 1)
#define CIDK_PP_DISABLE 0x00
#define CIDK_PP_ENABLE 0x02

// Define possible values for CIDK_DEC Enable (bit 0)
#define CIDK_DEC_DISABLE 0x00
#define CIDK_DEC_ENABLE 0x01

// typedef struct {
//     unsigned short dap_tuning;  // DAP tuning file selection
//     unsigned short tx_channel;  // TX channel selection
//     unsigned short cidk_pp;     // CIDK_PP enable/disable
//     unsigned short cidk_dec;    // CIDK_DEC enable/disable
// } Config;

uint32_t dap_tuning;
uint32_t tx_channel;
uint32_t cidk_pp;
uint32_t cidk_dec;
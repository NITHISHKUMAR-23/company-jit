#include "header.h"

int main()
{
//     Config BITS;
    uint32_t input_value = 0x20012007;

    //Extract the individual bit fields from the input value
    dap_tuning = input_value & DAP_TUNING_MASK;   
    tx_channel = input_value & TX_CHANNEL_MASK;
    cidk_pp = input_value & CIDK_PP_MASK;
    cidk_dec = input_value & CIDK_DEC_MASK;

    // BITS.dap_tuning = input_value & DAP_TUNING_MASK;   
    // BITS.tx_channel = input_value & TX_CHANNEL_MASK;
    // BITS.cidk_pp = input_value & CIDK_PP_MASK;
    // BITS.cidk_dec = input_value & CIDK_DEC_MASK;

    // Print the extracted values and interpret them
    printf("Input value: 0x%08X\n", input_value);

    // DAP Tuning
    printf("DAP_Tuning: ");
    switch (/*BITS.*/dap_tuning)
    {
    case DAP_TUNING_NONE:
        printf("None\n");
        break;
    case DAP_TUNING_FILE1:
        printf("Tuning file 1\n");
        break;
    case DAP_TUNING_FILE2:
        printf("Tuning file 2\n");
        break;
    case DAP_TUNING_FILE3:
        printf("Tuning file 3\n");
        break;
    default:
        printf("Unknown tuning value\n");
        break;
    }

    // TX Channel
    printf("TX Channel: ");
    switch (/*BITS.*/tx_channel)
    {
    case TX_CHANNEL_1_16:
        printf("TX Channel 1-16\n");
        break;
    case TX_CHANNEL_17_32:
        printf("TX Channel 17-32\n");
        break;
    default:
        printf("Unknown TX channel\n");
        break;
    }

    // CIDK_PP_Enable
    printf("CIDK_PP: ");
    if (/*BITS.*/cidk_pp == CIDK_PP_ENABLE)
    {
        printf("Enabled\n");
    }
    else
    {
        printf("Disabled\n");
    }

    // CIDK_DEC_Enable
    printf("CIDK_DEC: ");
    if (/*BITS.*/cidk_dec == CIDK_DEC_ENABLE)
    {
        printf("Enabled\n");
    }
    else
    {
        printf("Disabled\n");
    }

    return 0;
}

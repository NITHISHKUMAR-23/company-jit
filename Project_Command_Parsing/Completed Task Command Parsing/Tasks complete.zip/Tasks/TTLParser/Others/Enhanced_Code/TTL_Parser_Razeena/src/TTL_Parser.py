
import yaml
import json


PRINT_LINE_LENGTH = 100  
JSON = 0 # reference file format
YAML = 1 # reference file format

#*************************************************************************************************************************************************************************
#  Module Name        : extract_bitfields_parameter                                                                                                                      *
#  Functionality      : Extracts and processes bitfield information from a given command parameter,                                                                      *
#                       generates a formatted result string based on the data, and returns the result.                                                                   *
#                       The function supports data in YAML or JSON format and extracts bitfields                                                                         
#                       from a specified parameter number.
#                       
#  Input Parameters   : 
#    command_value    : int  - The command value that contains the bitfields to be extracted.
#    parameter_values : int  - The value associated with the parameter containing bitfields.
#    datas            : str  - The string representing the data in either YAML or JSON format.
#    path             : str  - The file path (currently not used in the function but can be extended).
#    file_format      : int  - The file format: 0 for YAML, 1 for JSON. Other values result in an error.
#  
#  Output Parameters  : 
#    result           : str  - A formatted string containing the processed bitfields and their associated values.
#    json_string      : str  - A JSON string representation of the parsed data.
#    status_code      : int  - A status code where 1 indicates success and 0 indicates an error.
#***************************************************************************************************************************************************************************
 
# command, parameter, parser.parameter_count, parser.Dict, "false", false)

import json
import yaml

def extract_bitfields_parameter(command_value, parameter_values, datas, path, file_format):
    # Initialize an empty string to store the result
    result = " "
    parameter_number = (parameter_values >> 16) & 15  # Extract the bits
    
    # Parse the data based on the file format (YAML or JSON)
    if file_format == 0:
        # Parse the data as YAML
        data = yaml.safe_load(datas)
    elif file_format == 1:
        # Parse the data as JSON
        data = json.loads(datas)
    else:
        # If the file format is not recognized, print an error
        print("No file is there.")
        return

    try:
        # Construct the key for the parameter and prepare the result string
        accessed_parameter = f"parameter{str(parameter_number)}"
        parameter = f"{'Parameter number'} : {str(parameter_number)}"
        result += "\n" + parameter + "\n" + "\n"
        
        # Check if the accessed parameter exists in the "parameters" section of the data
        if accessed_parameter not in data["parameters"]:
            print(f"Error: {accessed_parameter} not found in parameters.")
            return
        
        # Access the parameter's data
        accessed_param = data["parameters"][accessed_parameter]
        
        # Check if the accessed parameter contains "bitfields"
        if isinstance(accessed_param, dict) and "bitfields" in accessed_param:
            # Iterate over the bitfields in the accessed parameter
            for bitfield, bitfield_data in accessed_param["bitfields"].items():
                
                # If the bitfield is a range (e.g., '15-14')
                if '-' in bitfield:
                    # Split the bitfield range and create a mask to extract the specified bits
                    start, end = map(int, bitfield.split('-'))
                    mask = (1 << (start - end + 1)) - 1  # Create the mask for the bit range
                    
                    extracted_bits_int = (parameter_values >> end) & mask  # Extract the bits
                    # Convert the extracted bits to binary
                    extracted_bits_bin = bin(extracted_bits_int)[2:].zfill(start - end + 1)
                    
                    # Process the bitfield name and value
                    bitfield_data = accessed_param["bitfields"].get(bitfield)
                    if bitfield_data:
                        field_name = bitfield_data.get("name")
                        values = bitfield_data.get("values") or bitfield_data.get("Values", {})
                        value_description = values.get(extracted_bits_bin, values.get("default"))
                        
                        if field_name and value_description:
                            result += f"-> {field_name:<41} : {value_description}\n"
                else:  # If the bitfield is a single bit (e.g., '0')
                    extracted_bits_bin = (parameter_values >> int(bitfield)) & 1  # Extract the single bit
                    
                    # Process the bitfield name and value
                    bitfield_data = accessed_param["bitfields"].get(bitfield)
                    if bitfield_data:
                        field_name = bitfield_data.get("name")
                        values = bitfield_data.get("values") or bitfield_data.get("Values", {})
                        value_description = values.get(str(extracted_bits_bin), values.get("default"))
                        
                        if field_name and value_description:
                            result += f"-> {field_name:<41} : {value_description}\n"
        else:
            # If the parameter doesn't contain 'bitfields', print an error
            print(f"Error: {accessed_parameter} is not a dictionary or missing 'bitfields'.")
               
    except KeyError as e:
        # Catch any KeyError (missing keys in the data) and print an error message
        print(f"Error: Missing expected key in JSON data: {e}")
    except ValueError as e:
        # Catch any ValueError (invalid values, such as non-integer values) and print an error message
        print(f"Error: Invalid value encountered. Ensure parameter values are in correct format. {e}")
   
    # Return the result along with the JSON string of the data and a status code of 1
    return result, json.dumps(data), 1


#*******************************************************************************************************************************************************************
#  Module Name        : Command Validation Module                                                                                                                       *
#  Functionality      : This module validates a command from a file (either JSON or YAML) and retrieves details about it.
#                       It loads the file based on the provided file format (JSON or YAML) and checks if the specified command
#                       exists in the dictionary. If the command exists, it returns the command's name, its full details in JSON format,
#                       and the number of parameters associated with the command. If the command is not found, it returns an "invalid command" response.
#  
#  Input Parameters   :
#    - command (str): The name of the command to be validated.
#    - parameter (str): A parameter for the command.
#    - parameter_no (int): The number of parameters in the file.
#    - dictionary (dict): The file loaded from the path.
#    - path (str): The path to the file containing the commands (either JSON or YAML).
#    - file_format (int): Format indicator for the file.
#                         - 1: JSON format
#                         - 0: YAML format
#
#  Output  :
#    - If the command is found in the loaded dictionary:
#        - (str): Command name.
#        - (str): Command details as a JSON string.
#        - (int): The number of parameters for the command.
#    - If the command is not found:
#        - ("invalid command", "invalid dictionary", 0)
#***************************************************************************************************************************************************************************

def command_validation(command,parameter,dictionary,path,file_format): # This function validates a command from a file (either JSON or YAML) and retrieves details about it.

    if file_format == JSON:    # Check if the file format is JSON (file_format == 1)
        with open(path, "r") as file:
            dict = json.load(file)  # Parse the file content into a Python dictionary
    elif file_format == YAML:  # If the file format is YAML (file_format == 0)
        with open(path, "r") as file:
            dict = yaml.safe_load(file) # Parse the file content into a Python dictionary

    if command in dict: # Check if the provided command exists in the dictionary (loaded from the file)
        # If the command exists, return the the name of the command, command's full details as a JSON string and number of parameters for the command
        if "parameters" in dict[command]:
            return (dict[command]["name"], json.dumps(dict[command]), len(dict[command]["parameters"]))  # Convert dictionary to JSON string
        else:
            return (dict[command]["name"], json.dumps(dict[command]),0)
    else:
        return ("invalid command","invalid dictionary",0)   # If the command is not found in the dictionary, return a invalid command



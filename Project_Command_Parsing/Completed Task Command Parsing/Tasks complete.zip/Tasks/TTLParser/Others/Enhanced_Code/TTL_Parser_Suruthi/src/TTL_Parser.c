#include "TTL_Parser.h" // Include the header file for the TTL Parse

uint8_t Check_command(char ttl_data[])
{
    // Convert ttl_data to an unsigned long (hex to integer)
    uint32_t ttl_value = (uint32_t)strtoul(ttl_data, NULL, 16);
    // Check if bits 28 to 31 are 0 (command validity check)
    if (((ttl_value >> 28)&0xF)!= 2)
    {
        // Invalid command, set parameter buffer to 0 and return UNDEFINED
        Parameter_buffer[Parameter_count++] = (uint32_t)(0);
        return UNDEFINED;
    }

    // Check the value of bits 16 to 19
    uint32_t cmd_check = (ttl_value >> 16) & 0xF;  // Extract bits 16-19
    if (cmd_check == 0)  // If the value is 0, it's a command
    {
        // Store the command in Full_command and reset the parameter count
        send_command = ttl_data;
        strcat(Full_command, send_command);
        Current_Parameter_count = Parameter_count;
        Parameter_count = 0;
        return SUCCESS;
    }
    else if (cmd_check > 0 && cmd_check < 16)  // If the value is between 1 and 15, it's a parameter
    {
        // If it's a parameter, store it in the parameter buffer
        Parameter_buffer[Parameter_count++] = ttl_value;
        if (Parameter_count > 16)  // Check if buffer size exceeds 16
        {
            // Invalid parameter count, reset buffer and return UNDEFINED
            Parameter_buffer[Parameter_count++] = (uint32_t)(0);
            return UNDEFINED;
        }
        return FAILURE;  // Valid parameter
    }
    else  // Invalid value for command/parameter
    {
        // Reset parameter buffer and return UNDEFINED
        Parameter_buffer[Parameter_count++] = (uint32_t)(0);
        return UNDEFINED;
    }
}


char *dict = NULL;
// C to Python call function definition
// Pass the arguments appropriately to the respective function you want to access, ensuring they align with the function's parameter requirements.

char *c_to_python_call(char *function_name, char *command, int parameter, char *dictionary, char *path, uint32_t reference_file_type)
{
    // Initialize the Python interpreter
    Py_Initialize();

    // Import the Python script
    PyObject *pName = PyUnicode_FromString("TTL_Parser"); // Python module name
    PyObject *pModule = PyImport_Import(pName);
    Py_DECREF(pName);

    if (pModule != NULL)
    {
        // Get the function from the Python script
        PyObject *pFunc = PyObject_GetAttrString(pModule, function_name);

        if (pFunc && PyCallable_Check(pFunc))
        {
            // Call the Python function and get the result (JSON string)
            PyObject *pArg = PyTuple_Pack(5,
                                          PyUnicode_FromString(command),
                                          PyLong_FromLong(parameter),
                                          PyUnicode_FromString(dictionary),
                                          PyUnicode_FromString(path),
                                          PyLong_FromLong(reference_file_type));

            PyObject *pValue = PyObject_CallObject(pFunc, pArg);

            if (pValue != NULL)
            {
                // Return the JSON string
                Py_XDECREF(pFunc);
                Py_DECREF(pModule);

                parser.parameter_count = PyLong_AsLong(PyTuple_GetItem(pValue, 2));
                parser.Dict = (char *)PyUnicode_AsUTF8(PyTuple_GetItem(pValue, 1));
                return (char *)PyUnicode_AsUTF8(PyTuple_GetItem(pValue, 0));
                // return pValue; // Return JSON string
            }
            else
            {
                PyErr_Print();
                fprintf(stderr, "Failed to call Python function '%s'.\n", function_name);
            }
        }
        else
        {
            if (PyErr_Occurred())
                PyErr_Print();
            fprintf(stderr, "Cannot find function '%s'.\n", function_name);
        }

        Py_XDECREF(pFunc);
        Py_DECREF(pModule);
    }
    else
    {
        PyErr_Print();
        fprintf(stderr, "Failed to load 'parser' module.\n");
    }

    // Finalize the Python interpreter
    Py_Finalize();
    return NULL;
}

 // Static buffer for storing the hex value



char *extractHexValues(const char *line)
{
 
    static char hexValue[MAX_HEX_LENGTH + 1]; // 8 hex digits + null terminator
    char *tokenSendln = strstr(line, "sendln '");
 
    if (tokenSendln != NULL)
    {
        sscanf(tokenSendln, "sendln '0x%8s", hexValue); // Adjusted to read full 8 digits after 0x
        if ((hexValue[MAX_HEX_LENGTH] == '\'') || (hexValue[MAX_HEX_LENGTH - 1] == '\0') || (tokenSendln[HEX_WITH_SENDLN] != '\''))
        {
            printf("Invalid TTL format -> %s\n", line);
            hexValue[0] = '\0';
        }
        hexValue[MAX_HEX_LENGTH] = '\0'; // Ensure null termination
        for(int i=0;i<=MAX_HEX_LENGTH-1;i++)
        {
            if(!(isxdigit(hexValue[i])))
            {
                return NULL;
            }
        }
        return hexValue;
    }
   
    return NULL;
}


int command_identification(char *command, char *path, int file_format, char **Command_Name) // Function to identify and validate a command based on the file format and command string
{
    // Call the Python function 'command_validation' from the Python script and pass parameters
    *Command_Name = c_to_python_call("command_validation", command, false, "false", path, file_format);
    if (strstr(*Command_Name, "invalid"))
    {
        return FAILURE;
    }
    Command_Parameter_count = parser.parameter_count;
    return SUCCESS;
}

// Function to identify a parameter by invoking a Python method
char *parameter_identification(char *command, uint32_t parameter, char *dictionary, uint32_t reference_file_type)
{
    // Call the Python function `extract_bitfields_parameter` with the provided arguments
    char *output = c_to_python_call(
        "extract_bitfields_parameter",
        command,
        parameter,
        parser.Dict,
        "false",
        reference_file_type);
    // Print the output returned by the Python function
    // printf("%s", output);
    return output;
}


void double_long_line()
{
    for (int i = 0; i < PRINT_LINE_LENGTH; i++)
    {                            // 88 is the number of dashes you need
        fputc('=', output_file); // Print a dash
    }
    fputc('\n', output_file); // Print a newline at the end
}


void InitializeMetaData(char *TTL_file, time_t now, char *day, char *author)
{
    double_long_line();
    fprintf(output_file, "Given TTL file : TTL_Input_file");
    time(&now);
    strftime(day, DATE_BUFFER_SIZE, "\t\t\t\t\tTime : %H:%M:%S \t\t\t\t Date : %d-%m-%Y", localtime(&now));
    fprintf(output_file, "%s\n", day);
    fprintf(output_file, "Author : %s\n", author);
}

void writeparamAndBitfieldDetails(const char *paramAndBitfieldDetails)
{
    if (paramAndBitfieldDetails != NULL)
    {
        fprintf(output_file, "%s\n", paramAndBitfieldDetails);
    }
}

void writeCommand(const char *commandValue, char *Full_command)
{
    if (commandValue != NULL)
    {
        fprintf(output_file, "%35s : %s (%s)\n", "Command", commandValue, Full_command);
    }
}

int main(int argc, char *argv[])
{
      // Ensure the correct number of arguments are provided
    if (argc != 4)
    {
        fprintf(stderr, "Usage: %s <TTL_File> <OUT_File> <Reference_File>\n", argv[0]);
        return EXIT_FAILURE;
    }

    // Get file paths from the command line arguments
    char *TTL_File = argv[1];
    char *OUT_File = argv[2];
    char *Reference_File_Path = argv[3];
    const char *ext = strrchr(Reference_File_Path, '.');  // Find last occurrence of '.'

    if (ext != NULL)
    {
        if (strcmp(ext, ".json") == 0)
        {
            reference_file_type = JSON;
        }
        else if (strcmp(ext, ".yaml") == 0 || strcmp(ext, ".yml") == 0)
        {
            reference_file_type = YAML;
        }
        else
        {
            printf("Error: Both files must be either .json or .yaml/.yml\n");
            return EXIT_FAILURE;
        }
    }
    else
    {
        printf("Error: There is no any file extension for the reference file\n");
        return EXIT_FAILURE;
    }

    input_file = fopen(TTL_File, "r");
    // Error Handling on input TTL file and output.txt file
    if (!input_file)
    {
        printf("Error opening input file\n");
        return EXIT_FAILURE;
    }

    // Move the file pointer to the end of the file to get the size
    fseek(input_file, 0, SEEK_END);
    long file_size = ftell(input_file); // Get the size of the file

    // If the file size is zero, the file is empty
    if (file_size == 0)
    {
        printf("Input file is empty\n");
        fclose(input_file);
        return EXIT_FAILURE;
    }

    // Reset file pointer to the beginning for reading
    fseek(input_file, 0, SEEK_SET);

    // Open the output file
    output_file = fopen(OUT_File, "w");
    if (!output_file)
    {
        printf("Error opening output file\n");
        fclose(input_file);
        return EXIT_FAILURE;
    }

    time_t now;
    char day[DATE_BUFFER_SIZE];
    char *username = getenv("USER"); // To print Author Name

    if (username == NULL)
    {
        username = getenv("USERNAME");
    }

    InitializeMetaData(TTL_File, now, day, username); // To Initialize MetaData

    char line[LINE_SIZE];
    while (fgets(line, sizeof(line), input_file))
    {

        // Remove trailing newline character
        line[strcspn(line, "\n")] = '\0';

        // Skip lines that start with "mpause", comment lines starting with "//", empty lines, or lines with only spaces
        if (strncmp(line, "mpause", 6) == 0 || strncmp(line, "//", CMNT_SLASH_SIZE) == 0 || line[0] == '\0' || strspn(line, " \t\r\n") == strlen(line))
        {
            // Print an invalid line message only for empty or whitespace-only lines
            if (line[0] == '\0' || strspn(line, " \t\r\n") == strlen(line))
            {
                printf("Invalid line present: %s\n", line);
                continue;
            }
            continue; // Skip this line and move to the next one
        }
        if (strncmp(line, "sendln '", 8) == 0) 
        {
           
            char *hexValue = extractHexValues(line);
            if (hexValue != NULL)
            {
                strcpy(Full_command, "0x");
                uint8_t Status = Check_command(hexValue); 
                if (Status == SUCCESS)
                {
                    Command_Name = NULL;
                    // Call the command_identification function to process the command and retrieve the result
                    if (command_identification(Full_command, Reference_File_Path, reference_file_type, &Command_Name) == 0)
                    {
                        printf("%s is %s\n", Full_command, Command_Name);
                        continue; // this should be uncommand while integrating
                    }
                    double_long_line();
                    uint32_t starting_param_count=0;
                    if(Current_Parameter_count==0 && Command_Parameter_count!=0)
                    {
                        printf("There is no parameter for %s command in TTL_Input_file\n",Command_Name);
                    }
                    else
                    {
                        writeCommand(Command_Name, Full_command);
                    }
                    if(Current_Parameter_count>=Command_Parameter_count)
                    {
                        starting_param_count=Current_Parameter_count-Command_Parameter_count;
                    }
                    for (uint32_t i = starting_param_count; i < Current_Parameter_count; i++)
                    {
                        // Check if the current parameter in the buffer is not zero
                        if (Parameter_buffer[i] != 0)
                        {
                            
                                parameter_string=NULL;
                                // Call the `parameter_identification` function to process the parameter
                                // `parameter_identification` returns a string based on the processing of the parameter
                                parameter_string = parameter_identification(
                                Full_command,
                                Parameter_buffer[i],
                                parser.Dict,
                                reference_file_type);

                            writeparamAndBitfieldDetails(parameter_string);
                            fputc('\n', output_file);                                     
                        }
                    }
                }
                 else if (Status == UNDEFINED)
                {
                    printf("%s : is an Invalid Command or Parameter\n", hexValue);
                }
            }
            else
            {
                printf("Error:Invalid command or parameter hex_value");
                continue;
            }
        }
        else 
        {
                printf("Error: Invalid sendln line (invalid hex value): %s\n", line);
        }
 
    }
    double_long_line();
    fclose(input_file);
    fclose(output_file);
    return 0;
}
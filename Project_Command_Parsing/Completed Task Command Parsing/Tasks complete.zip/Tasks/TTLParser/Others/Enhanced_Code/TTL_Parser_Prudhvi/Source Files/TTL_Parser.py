
import yaml
import json


PRINT_LINE_LENGTH = 100  


#*************************************************************************************************************************************************************************
#  Module Name        : extract_bitfields_parameter                                                                                                                      *
#  Functionality      : Extracts and processes bitfield information from a given command parameter,                                                                      *
#                       generates a formatted result string based on the data, and returns the result.                                                                   *
#                       The function supports data in YAML or JSON format and extracts bitfields                                                                         
#                       from a specified parameter number.
#                       
#  Input Parameters   : 
#    command_value    : int  - The command value that contains the bitfields to be extracted.
#    parameter_values : int  - The value associated with the parameter containing bitfields.
#    parameter_number : int  - The number of the parameter to access in the provided data.
#    datas            : str  - The string representing the data in either YAML or JSON format.
#    path             : str  - The file path (currently not used in the function but can be extended).
#    file_format      : int  - The file format: 0 for YAML, 1 for JSON. Other values result in an error.
#  
#  Output Parameters  : 
#    result           : str  - A formatted string containing the processed bitfields and their associated values.
#    json_string      : str  - A JSON string representation of the parsed data.
#    status_code      : int  - A status code where 1 indicates success and 0 indicates an error.
#***************************************************************************************************************************************************************************
 # Function to extract and process bitfield information from the given command parameter

def extract_bitfields_parameter(command_value, parameter_values, datas, path, file_format):
    # Parse the data based on the file format
    data = parse_file(datas, file_format)
    if not data:
        print("No file or unsupported format.")
        return
 
    # Extract parameter number
    parameter_number = extract_parameter_number(parameter_values)
    accessed_parameter = f"parameter{parameter_number}"
    result = f"\nParameter number : {parameter_number}\n\n"
 
    # Validate and process the parameter
    try:
        if not validate_parameter(data, accessed_parameter):
            print(f"Error: {accessed_parameter} not found in parameters.")
            return
 
        # Process bitfields, skipping default/reserved values
        result += process_bitfields(data, accessed_parameter, parameter_values)
       
        # Remove any empty lines from the result that were added when skipping values
        result = "\n".join([line for line in result.splitlines() if line.strip()])
       
    except KeyError as e:
        print(f"Error: Missing expected key in JSON data: {e}")
    except ValueError as e:
        print(f"Error: Invalid value encountered. Ensure parameter values are in correct format. {e}")
 
    # Return the result along with the JSON string of the data and a status code of 1
    return result, json.dumps(data), 1
 
 
# Function to parse file based on format (YAML or JSON)
def parse_file(datas, file_format):
    if file_format == 0:  # YAML
        return yaml.safe_load(datas)
    elif file_format == 1:  # JSON
        return json.loads(datas)
    else:
        return None
 
 
# Function to extract the parameter number from the parameter values
def extract_parameter_number(parameter_values):
    return (parameter_values >> 16) & 15
 
 
# Function to validate if the parameter exists in data
def validate_parameter(data, accessed_parameter):
    return accessed_parameter in data["parameters"]
 
 
# Function to process bitfields in the parameter
def process_bitfields(data, accessed_parameter, parameter_values):
    result = ""
    accessed_param = data["parameters"][accessed_parameter]
 
    if "bitfields" not in accessed_param:
        print(f"Error: {accessed_parameter} is missing 'bitfields'.")
        return result
 
    # Process each bitfield in the parameter
    for bitfield, bitfield_data in accessed_param["bitfields"].items():
        # Process single-bit or multi-bit fields
        if '-' in bitfield:
            result += process_bitfield_range(bitfield, bitfield_data, parameter_values, data, accessed_parameter)
        else:
            result += process_single_bit(bitfield, bitfield_data, parameter_values, data, accessed_parameter)
 
    return result
 
 
# Function to process a bitfield range (e.g., '15-12')
def process_bitfield_range(bitfield, bitfield_data, parameter_values, data, accessed_parameter):
    start, end = map(int, bitfield.split('-'))
    mask = (1 << (start - end + 1)) - 1
    extracted_bits_int = (parameter_values >> end) & mask
    extracted_bits_bin = bin(extracted_bits_int)[2:].zfill(start - end + 1)
 
    # Use helper to process the bitfield name and value
    return process_bitfield_value(data, accessed_parameter, bitfield, extracted_bits_bin)
 
 
# Function to process a single-bit field (e.g., '0')
def process_single_bit(bitfield, bitfield_data, parameter_values, data, accessed_parameter):
    bit_index = int(bitfield)
    extracted_bits_bin = str((parameter_values >> bit_index) & 1)
 
    # Use helper to process the bitfield name and value
    return process_bitfield_value(data, accessed_parameter, bitfield, extracted_bits_bin)
 
 
# Helper function to process a bitfield name and value, skipping default and reserved values
def process_bitfield_value(data, accessed_parameter, bitfield, extracted_bits_bin):
    accessed_param = data["parameters"][accessed_parameter]
 
    # Validate and fetch bitfield data
    if bitfield not in accessed_param["bitfields"]:
        return f"Bitfield {bitfield} not found in {accessed_parameter}.\n"
 
    bitfield_data = accessed_param["bitfields"][bitfield]
    bitfield_name = bitfield_data.get("name", "Unknown")
    bitfield_values = bitfield_data.get("values", {})
 
    # Match extracted bits to the values defined in the bitfield
    if extracted_bits_bin in bitfield_values:
        value_description = bitfield_values[extracted_bits_bin]
    elif "default" in bitfield_values:
        value_description = bitfield_values["default"]
        # Skip the bitfield if the value is the default or reserved
        if value_description in ["default", "Reserved", "Unknown value"]:
            return ""  # Return an empty string to skip the bitfield
    else:
        value_description = "Unknown value"
 
    # Build and return the result string, formatted with -> and proper alignment
    return f"-> {bitfield_name:<40} : {value_description}\n" if value_description not in ["Reserved", "Unknown value"] else ""
 
#***************************************************************************************************************************************************************************
#  Module Name        : Command Validation Module                                                                                                                       *
#  Functionality      : This module validates a command from a file (either JSON or YAML) and retrieves details about it.
#                       It loads the file based on the provided file format (JSON or YAML) and checks if the specified command
#                       exists in the dictionary. If the command exists, it returns the command's name, its full details in JSON format,
#                       and the number of parameters associated with the command. If the command is not found, it returns an "invalid command" response.
#  
#  Input Parameters   :
#    - command (str): The name of the command to be validated.
#    - parameter (str): A parameter for the command.
#    - parameter_no (int): The number of parameters in the file.
#    - dictionary (dict): The file loaded from the path.
#    - path (str): The path to the file containing the commands (either JSON or YAML).
#    - file_format (int): Format indicator for the file.
#                         - 1: JSON format
#                         - 0: YAML format
#
#  Output  :
#    - If the command is found in the loaded dictionary:
#        - (str): Command name.
#        - (str): Command details as a JSON string.
#        - (int): The number of parameters for the command.
#    - If the command is not found:
#        - ("invalid command", "invalid dictionary", 0)
#***************************************************************************************************************************************************************************

def command_validation(command,parameter_no,dictionary,path,file_format): # This function validates a command from a file (either JSON or YAML) and retrieves details about it.

    if file_format == 1:    # Check if the file format is JSON (file_format == 1)
        with open(path, "r") as file:
            dict = json.load(file)  # Parse the file content into a Python dictionary
    elif file_format == 0:  # If the file format is YAML (file_format == 0)
        with open(path, "r") as file:
            dict = yaml.safe_load(file) # Parse the file content into a Python dictionary

    if command in dict: # Check if the provided command exists in the dictionary (loaded from the file)
        # If the command exists, return the the name of the command, command's full details as a JSON string and number of parameters for the command
        if "parameters" in dict[command]:
            return (dict[command]["name"], json.dumps(dict[command]), len(dict[command]["parameters"]))  # Convert dictionary to JSON string
        else:
            return (dict[command]["name"], json.dumps(dict[command]),0)
    else:
        return ("invalid command","invalid dictionary",0)   # If the command is not found in the dictionary, return a invalid command
    

#/******************************************************************************************************************************************
#  Module Name        : bitfieldNameAndValue
#  Functionality      : This function retrieves and prints the name and value description of a specific bitfield within a given 
#                       parameter in a structured data format (like JSON). It navigates to the required section of the data, 
#                       checks for the existence of the specified parameter and bitfield, and fetches the corresponding 
#                       value description for the specified bit value. If the bit value is not found, it returns an error message.
#                       If the bitfield name is "Reserved", the function returns early without performing further actions.
#  Input Parameters   : data (dict)               : The structured data (typically a dictionary) containing parameters and bitfields.
#                       parameter_input (str)      : The name of the parameter whose bitfields will be examined.
#                       bitfield (str)             : The name of the bitfield within the specified parameter to fetch data for.
#                       bit_value (str)            : The specific bit value to fetch its description.
#  Output Parameters  : None                       : This function does not return any output but prints error messages or the 
#                                               bitfield name along with its corresponding value description.
#  Return Values      : str                        : Returns a formatted string with the bitfield name and its corresponding value description,
#                                               or None if the bitfield is labeled as "Reserved".
#******************************************************************************************************************************************/

def bitfieldNameAndValue(data, parameter_input, bitfield, bit_value):
    bit_value= str(bit_value)
 
    # Navigate directly to the parameter section in the JSON structure
    parameter_data = data.get("parameters", {}).get(parameter_input, {})
   
    if not parameter_data:
       
        print (f"Error: '{parameter_input}' not found.")
 
    parameter_name = parameter_input
 
    # Find the bitfield in the parameter's bitfields
    bitfield_data = parameter_data.get("bitfields", {}).get(bitfield, {}) or parameter_data.get("Bitfields", {}).get(bitfield, {})
   
    if not bitfield_data:
       
        print (f"Error: '{bitfield}' not found in '{parameter_name}'.")
 
    # Extract the name of the bitfield
    field_name = bitfield_data.get("name")
 
    #print(field_name)
    if field_name == "Reserved":
        return
 
    # Get the values dictionary, which contains the descriptions for different bit values
    values = bitfield_data.get("values", {}) or bitfield_data.get("Values", {})
   
    # Get the description for the provided bit_value, or use the default description if not provided
    value_description = values.get(bit_value, values.get("default"))
 
 
    if not value_description:
       
        print(f"Error: Bit value '{bit_value}' not found for bitfield '{bitfield}'.")
 
    # Return the formatted string with parameter and bitfield information on separate lines
    return f"{"-> "}{field_name:<41} : {value_description}"
 

#include "TTL_Parser.h" // Include the header file for the TTL Parser

/******************************************************************************************************************************************
 *  Function Name      : is_valid_hex
 *  Functionality      : Checks whether a given character is a valid hexadecimal character.
 *  Input Parameters   : c (uint8_t) : The character to check.
 *  Output Parameters  : uint8_t     : Returns 1 if the character is a valid hex character, otherwise 0.
 ******************************************************************************************************************************************/
uint8_t is_valid_hex(uint8_t c)
{
    return ((c >= '0' && c <= '9') || (c >= 'A' && c <= 'F') || (c >= 'a' && c <= 'f'));
}
 
/******************************************************************************************************************************************
 *  Function Name      : validate_hex_string
 *  Functionality      : Validates if all characters in a given string are valid hexadecimal characters.
 *  Input Parameters   : ttl_data (uint8_t[]) : The string to validate.
 *                       Length (uint8_t)     : Length of the string.
 *  Output Parameters  : uint8_t              : Returns SUCCESS if all characters are valid hex, otherwise FAILURE.
 ******************************************************************************************************************************************/
uint8_t validate_hex_string(uint8_t ttl_data[], uint8_t Length)
{
    for (int i = 0; i < Length; i++)
    {
        if (!is_valid_hex(ttl_data[i]))
        {
            return FAILURE;
        }
    }
    return SUCCESS;
}
 
/******************************************************************************************************************************************
 *  Function Name      : Check_command
 *  Functionality      : Validates a TTL command and processes its parameters.
 *                       If the command is valid, stores parameters in the buffer and updates the global state.
 *  Input Parameters   : ttl_data (uint8_t[])       : The TTL command string.
 *                       Parameter_buffer (uint32_t*): Buffer to store extracted parameters.
 *  Output Parameters  : uint8_t                    : Returns SUCCESS, FAILURE, or INVALID based on the command validity.
 ******************************************************************************************************************************************/
uint8_t Check_command(uint8_t ttl_data[], uint32_t *Parameter_buffer)
{
    if (ttl_data[0] == '2' && ttl_data[2] == '0' && ttl_data[3] == '0')
    {
        if (!validate_hex_string(ttl_data, MAX_HEX_LENGTH))
        {
            Parameter_buffer[Parameter_count++] =0
            return INVALID;
        }
        send_command = ttl_data;
        strncat(Full_command, (char *)send_command, FULL_COMMAND_LENGTH - 1);
        Current_Parameter_count = Parameter_count;
        Parameter_count = 0;
        return SUCCESS;
    }
    else if ((ttl_data[0] == '2'))
    {
        if (!validate_hex_string(ttl_data, MAX_HEX_LENGTH))
        {
            Parameter_buffer[Parameter_count++] = (uint32_t)(0);
            return INVALID;
        }
        Parameter_buffer[Parameter_count++] = (uint32_t)strtoul((char *)ttl_data, NULL, 16);
        return FAILURE;
    }
    else
    {
        Parameter_buffer[Parameter_count++] = (uint32_t)(0);
        return INVALID;
    }
}

/******************************************************************************************************************************************
 *  Function Name      : c_to_python_call
 *  Functionality      : Calls a Python function with the given arguments and returns the result.
 *  Input Parameters   : function_name (char*): Name of the Python function to call.
 *                       command (char*)      : Command string.
 *                       parameter (int)      : Parameter value.
 *                       dictionary (char*)   : Dictionary string.
 *                       path (char*)         : Path to the reference file.
 *                       reference_file_type (uint32_t): Reference file type.
 *  Output Parameters  : char*                : Returns the result from the Python function as a string.
 ******************************************************************************************************************************************/
char *c_to_python_call(char *function_name, char *command, int parameter, char *dictionary, char *path, uint32_t reference_file_type)
{
    Py_Initialize();
    PyObject *pName = PyUnicode_FromString("TTL_Parser");
    PyObject *pModule = PyImport_Import(pName);
    Py_DECREF(pName);

    if (pModule != NULL)
    {
        PyObject *pFunc = PyObject_GetAttrString(pModule, function_name);

        if (pFunc && PyCallable_Check(pFunc))
        {
            PyObject *pArg = PyTuple_Pack(5,
                                          PyUnicode_FromString(command),
                                          PyLong_FromLong(parameter),
                                          PyUnicode_FromString(dictionary),
                                          PyUnicode_FromString(path),
                                          PyLong_FromLong(reference_file_type));

            PyObject *pValue = PyObject_CallObject(pFunc, pArg);

            if (pValue != NULL)
            {
                Py_XDECREF(pFunc);
                Py_DECREF(pModule);

                parser.parameter_count = PyLong_AsLong(PyTuple_GetItem(pValue, 2));
                parser.Dict = (char *)PyUnicode_AsUTF8(PyTuple_GetItem(pValue, 1));
                return (char *)PyUnicode_AsUTF8(PyTuple_GetItem(pValue, 0));
            }
            else
            {
                PyErr_Print();
                fprintf(stderr, "Failed to call Python function '%s'.\n", function_name);
            }
        }
        else
        {
            if (PyErr_Occurred())
                PyErr_Print();
            fprintf(stderr, "Cannot find function '%s'.\n", function_name);
        }

        Py_XDECREF(pFunc);
        Py_DECREF(pModule);
    }
    else
    {
        PyErr_Print();
        fprintf(stderr, "Failed to load 'TTL_Parser' module.\n");
    }

    Py_Finalize();
    return NULL;
}

/******************************************************************************************************************************************
 *  Function Name      : extractHexValues
 *  Functionality      : Extracts a hexadecimal value from a line containing a "sendln" command.
 *  Input Parameters   : line (const char*): Input line containing the "sendln" command.
 *  Output Parameters  : char*             : Extracted hexadecimal value as a string, or NULL if invalid.
 ******************************************************************************************************************************************/
char *extractHexValues(const char *line)
{
    static char hexValue[MAX_HEX_LENGTH + 1];
    char *tokenSendln = strstr(line, "sendln '");

    if (tokenSendln != NULL)
    {
        sscanf(tokenSendln, "sendln '0x%8s", hexValue);
        if ((hexValue[MAX_HEX_LENGTH] == '\'') || (hexValue[MAX_HEX_LENGTH - 1] == '\0') || (tokenSendln[HEX_WITH_SENDLN] != '\''))
        {
            printf("Invalid TTL format -> %s\n", line);
            hexValue[0] = '\0';
        }
        hexValue[MAX_HEX_LENGTH] = '\0';
        return hexValue;
    }
    else
    {
        printf("Invalid TTL format -> %s\n", line);
    }
    return NULL;
}

/*  Function to write the bitfield name and value to the output file
    This function writes the provided bitfield name and value to the output file if they are not NULL.

    Parameters:
    - const char* param1 ->String 1 to write into the file
    - const char* param2 ->String 2 to write into the file

    Returns:
    - Write Status
*/
bool writeAPI(const char *param1, const char *param2)
{
    if (param2 == NULL)
    {
        fprintf(output_file, "%s\n", param1);
    }
    else
    {
        fprintf(output_file, "%35s : %s (%s)\n", "Command", param1, param2);

    }
    for (int i = 0; i < PRINT_LINE_LENGTH; i++)
    {                            
        fputc('=', output_file); // Print a dash
    }
    fputc('\n', output_file); // Print a newline at the end
    return SUCCESS;
  
}


/******************************************************************************************************************************************
 *  Function Name      : InitializeMetaData
 *  Functionality      : Initializes and writes metadata to the output file, including TTL file name, time, date, and author.
 *  Input Parameters   : TTL_file (char*): The name of the TTL file.
 *                       now (time_t)    : Current time.
 *                       day (char*)     : Buffer to store formatted date and time.
 *                       author (char*)  : Author's username.
 *  Output Parameters  : None
 ******************************************************************************************************************************************/
void InitializeMetaData(char *TTL_file, time_t now, char *day, char *author)
{
    fprintf(output_file, "Given TTL file : TTL_Input_file");
    time(&now);
    strftime(day, DATE_BUFFER_SIZE, "\t\t\t\t\tTime : %H:%M:%S \t\t\t\t Date : %d-%m-%Y", localtime(&now));
    fprintf(output_file, "%s\n", day);
    fprintf(output_file, "Author : %s\n", author);
}

/******************************************************************************************************************************************
 *  Function Name      : command_identification
 *  Functionality      : Identifies and validates a command using Python validation and checks for invalid strings.
 *  Input Parameters   : command (char*): The command string to validate.
 *                       path (char*): File path for validation.
 *                       file_format (int): Format of the reference file (JSON/YAML).
 *                       Command_Name (char**): Pointer to store the validated command name.
 *                       Parameter_buffer (uint32_t*): Buffer to store parameters.
 *  Output Parameters  : int: Returns SUCCESS if valid, otherwise FAILURE.
 ******************************************************************************************************************************************/
int command_identification(char *command, char *path, int file_format, char **Command_Name, uint32_t *Parameter_buffer)
{
    *Command_Name = c_to_python_call("command_validation", command, false, "false", path, file_format);
    if (strstr(*Command_Name, "invalid"))
    {
        free(Parameter_buffer);
        return FAILURE;
    }
    Command_Parameter_count = parser.parameter_count;
    return SUCCESS;
}

/******************************************************************************************************************************************
 *  Function Name      : parameter_identification
 *  Functionality      : Identifies a parameter by calling a Python method with the provided arguments.
 *  Input Parameters   : command (char*): Command string.
 *                       parameter (uint32_t): Parameter value.
 *                       dictionary (char*): Dictionary string.
 *                       reference_file_type (uint32_t): Reference file type.
 *  Output Parameters  : char*: Returns the parameter name as a string.
 ******************************************************************************************************************************************/
char *parameter_identification(char *command, uint32_t parameter, char *dictionary, uint32_t reference_file_type)
{
    char *output = c_to_python_call(
        "extract_bitfields_parameter",
        command,
        parameter,
        parser.Dict,
        "false",
        reference_file_type);
    return output;
}


// Main function
int main(int args, char *argv[])
{
    if (args != MAX_ARGS)
    {
        printf("Give the Input as follows %s :  <TTL_File> <Reference_File> <Output_File> <Reference_File_Type>\n",argv[0]);
        return EXIT_FAILURE; // Exit program with failure code
    }
    // Getting arguments at run time
    char *TTL_File = argv[1];                // Input TTL file
    char *Reference_File_Path = argv[2];     // Path to the reference file (JSON or YAML)
    char *OUT_File = argv[3];                // Path to the output file
    int reference_file_type = atoi(argv[4]); // Reference file type (0 = JSON, 1 = YAML)

    time_t now = 0;
    char day[DATE_BUFFER_SIZE];
    char *username = getenv("USER"); // To print Author Name

    if (username == NULL)
    {
        username = getenv("USERNAME");
    }

    input_file = fopen(TTL_File, "r");

    if (reference_file_type != JSON && reference_file_type != YAML)
    {
        printf("Error: 'Reference_File_Type' must be 0 (JSON) or 1 (YAML).\n");
        return EXIT_FAILURE;
    }

    if (!input_file)
    {
        perror("Error opening file");
        return EXIT_FAILURE;
    }
    output_file = fopen(OUT_File, "w");

    fseek(input_file, 0, SEEK_END);
    long file_size = ftell(input_file);

    if (file_size == 0)
    {
        printf("Error: The file '%s' is empty!\n", TTL_File);
        fclose(input_file);
        fclose(output_file);
        return EXIT_FAILURE;
    }

    fseek(input_file, 0, SEEK_SET);

    InitializeMetaData(TTL_File, now, day, username);

    char line[LINE_SIZE];

    // Allocate memory for Parameter_buffer
    uint32_t *Parameter_buffer = (uint32_t *)malloc(MAX_PARAMETERS_COUNT * sizeof(uint32_t));

    while (fgets(line, sizeof(line), input_file))
    {
        line[strcspn(line, "\n")] = '\0';
        if ((strcmp(line, "//") != 0) && (line[0] != '\0') && strspn(line, " \t\r\n") != strlen(line))
        {
            char *check_pointer = strstr(line, "sendln");
            if (check_pointer)
            {
                char *hexValue = extractHexValues(line);
                if (hexValue != NULL)
                {
                    strncpy(Full_command, "0x", 3);

                    if (Parameter_buffer == NULL)
                    {
                        fprintf(stderr, "Memory allocation failed for Parameter_buffer.\n");
                        fclose(input_file);
                        fclose(output_file);
                        return EXIT_FAILURE;
                    }

                    // Process the command
                    uint8_t Status = Check_command(hexValue, Parameter_buffer);
                    if (Status == SUCCESS)
                    {
                        char *Command_Name = NULL;
                        if (command_identification(Full_command, Reference_File_Path, reference_file_type, &Command_Name, Parameter_buffer) == FAILURE)
                        {
                            printf("%s is %s\n", Full_command, Command_Name);
                            continue;
                        }
                        write_status = writeAPI(Command_Name, Full_command);
    
                        for (uint32_t i = 0; i < Current_Parameter_count; i++)
                        {
                            if (Parameter_buffer[i] != 0)
                            {
                                uint32_t parameter_no = i + 1;
                                char *parameter_string = parameter_identification(
                                    Full_command,
                                    Parameter_buffer[i],
                                    parser.Dict,
                                    reference_file_type);
                                 write_status = writeAPI(parameter_string, NULL);
                            }
                        }
                    }
                    else if (Status == INVALID)
                    {
                        printf("%s : is an Invalid Command or Parameter\n", hexValue);
                    }
                }
            }
        }
    }
    free(Parameter_buffer);
    fclose(input_file);
    fclose(output_file);
    return 0;
}

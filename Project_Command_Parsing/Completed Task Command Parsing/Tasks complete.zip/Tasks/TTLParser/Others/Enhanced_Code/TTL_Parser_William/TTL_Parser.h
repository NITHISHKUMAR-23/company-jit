//Include all global declarations here
#include <python3.11/Python.h>  // Include the Python API for C (Python 3.12)
#include <stdio.h>  // Include standard input/output library
#include <stdbool.h>    // Include library for using boolean type
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>
#include <time.h>

#define MAX_PARAMETERS_COUNT 16
// #define MAX_HEX_LENGTH 11
// #define MAX_PARAMETERS_COUNT 40
#define MAX_HEX_LENGTH 8
#define FULL_COMMAND_LENGTH 11
#define LINE_SIZE 256
#define DATE_BUFFER_SIZE 100
#define PATH_SIZE 256
#define MAX_HEX_SIZE 9
#define HEX_WITH_SENDLN 18
#define PRINT_LINE_LENGTH 100
#define CMNT_SLASH_SIZE 2
#define MAX_ARGS 5
#define JSON 0
#define YAML 1

uint8_t Parameter_count = 0;
uint8_t Current_Parameter_count = 0;
char Full_command[FULL_COMMAND_LENGTH] = "\0";
char *send_command;
uint32_t reference_file_type = 1;  // 0 - denotes JSON and 1 - denotes YAML
bool write_status;
int32_t Command_Parameter_count=0;
FILE *input_file;       //input file pointer
FILE *output_file;      //output file pointer


typedef struct
{
    int parameter_count;
    char* Dict;
}Python_return_values; //If you need to store and pass any data, you can include it directly within the structure.

Python_return_values parser;
enum Status
{
    FAILURE,
    SUCCESS,
    INVALID
};
//Function declaration
bool writeAPI(const char *Command_Name, const char *Full_command);
int32_t command_identification(char* ,char* ,int ,char** ,uint32_t * );
uint8_t is_valid_hex(uint8_t c);
uint8_t Check_command(uint8_t *, uint32_t *);
// char* c_to_python_call(char*,char*,int,int,char*,char*,uint32_t *);
char* c_to_python_call(char* ,char* ,int ,char* ,char* ,uint32_t) ;

char* parameter_identification(char* ,uint32_t ,char* ,uint32_t );


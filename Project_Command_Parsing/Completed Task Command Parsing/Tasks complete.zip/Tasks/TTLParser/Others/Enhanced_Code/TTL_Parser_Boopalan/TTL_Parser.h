//Include all global declarations here
#include <Python.h>  
#include <stdio.h>  // Include standard input/output library
#include <stdbool.h>    // Include library for using boolean type
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>
#include <time.h>

#define MAX_PARAMETERS_COUNT 40
#define MAX_HEX_LENGTH 8
#define FULL_COMMAND_LENGTH 11
#define LINE_SIZE 256
#define DATE_BUFFER_SIZE 50
#define PATH_SIZE 256
#define HEX_WITH_SENDLN_SIZE 18
#define CMNT_SLASH_SIZE 2

uint32_t parameter_buffer[MAX_PARAMETERS_COUNT];
uint8_t parameter_count = 0;
uint8_t current_parameter_count = 0;
char full_command[FULL_COMMAND_LENGTH] = "\0";
char *send_command;
bool Json_Ref_File = true;
int32_t command_parameter_count=0;
bool isCommand = true;

char* TTL_File = "D:/Training/TTLParser/Code/VSCode/Release1.3/TTL_Parser/Input_Files/TTL_Input_file.ttl";
char* OUT_File = "Output.txt";
char* Json_File= "D:/Training/TTLParser/Code/VSCode/Release1.3/TTL_Parser/Input_Files/Command_Reference_JSON.json";
char* Yaml_File= "D:/Training/TTLParser/Code/VSCode/Release1.3/TTL_Parser/Input_Files/Command_Reference_YAML.yaml";

typedef struct
{
    int parameter_count;
    char* Dict;
}Python_return_values; 

Python_return_values parser;
enum Status
{
    FAILURE,
    SUCCESS,
    UNDEFINED
};

//Function declaration (Prototypes)
void double_long_line(FILE *, uint8_t);
uint8_t check_command(const uint8_t*);
void write_ttl_info(FILE *, uint8_t [], bool);
static inline bool is_valid_hex(const uint8_t);
uint8_t *extract_hex_values(const uint8_t *, uint32_t);
uint8_t *parameter_identification(const uint8_t *, uint32_t , const uint8_t *, bool );
uint32_t command_identification(const uint8_t *, const uint8_t *, uint32_t, uint8_t **);
uint8_t *c_to_python_call(uint8_t *, const uint8_t *, uint32_t, const uint8_t *, const uint8_t *, bool);
uint32_t file_handle_init_meta_data(FILE *, FILE *, uint8_t *, const uint8_t *, time_t, uint8_t *, const uint8_t *, uint8_t);


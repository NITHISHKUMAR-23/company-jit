#include "TTL_Parser.h"

/**
 * @brief Check if a character is a valid hexadecimal digit.
 * 
 * @param hex_char The character to check.
 * @return true if hex_char is a valid hexadecimal digit, false otherwise.
 */
static inline bool is_valid_hex(const uint8_t hex_char)
{
    return (hex_char >= '0' && hex_char <= '9') ||
           (hex_char >= 'A' && hex_char <= 'F') ||
           (hex_char >= 'a' && hex_char <= 'f');
}

/**
 * @brief Validate a TTL command and determine its type.
 * 
 * This function checks if the given TTL command is a valid hexadecimal command.
 * It identifies the type of the data(command or parameter) and updates global buffers accordingly.
 * 
 * @param ttl_data The TTL command data.
 * @return uint8_t SUCCESS(1) if the data is valid and starts with '2000' then command, 
 *                 FAILURE(0) if the data is valid and starts with '2'  then parameter, 
 *                 UNDEFINED(2) otherwise.
 */
uint8_t check_command(const uint8_t *ttl_data)
{
    for (uint32_t i = 0; i < MAX_HEX_LENGTH; ++i)
    {
        if (!is_valid_hex(ttl_data[i]))
        {
            parameter_buffer[parameter_count++] = 0;
            return UNDEFINED;
        }
    }

    if (ttl_data[0] == '2')
    {
        if (ttl_data[2] == '0' && ttl_data[3] == '0')
        {
            send_command = (char *)ttl_data;
            strncat(full_command, send_command, MAX_HEX_LENGTH);
            current_parameter_count = parameter_count;
            parameter_count = 0;
            return SUCCESS;
        }
        else
        {
            parameter_buffer[parameter_count++] = strtoul((const char *)ttl_data, NULL, 16);
            return FAILURE;
        }
    }
    else
    {
        parameter_buffer[parameter_count++] = 0;
        return UNDEFINED;
    }
}

/**
 * @brief Call a Python function from C code.
 * 
 * This function initializes the Python interpreter, calls the specified 
 * Python function with the given arguments, and returns the result.
 * 
 * @param function_name The name of the Python function to call.
 * @param command The command argument to pass to the Python function.
 * @param parameter The parameter argument to pass to the Python function.
 * @param dictionary The dictionary argument to pass to the Python function.
 * @param path The path argument to pass to the Python function.
 * @param Json_Ref_File The JSON reference file flag.
 * @return uint8_t* The result of the Python function call.
 */
uint8_t *c_to_python_call(uint8_t *function_name, const uint8_t *command, uint32_t parameter, const uint8_t *dictionary, const uint8_t *path, bool Json_Ref_File)
{
    Py_Initialize();
    PyObject *pName = PyUnicode_FromString("TTL_Parser");
    PyObject *pModule = PyImport_Import(pName);
    Py_DECREF(pName);

    if (pModule != NULL)
    {
        PyObject *pFunc = PyObject_GetAttrString(pModule, function_name);

        if (pFunc && PyCallable_Check(pFunc))
        {

            PyObject *pArg = PyTuple_Pack(5,
                                          PyUnicode_FromString(command),
                                          PyLong_FromLong(parameter),
                                          PyUnicode_FromString(dictionary),
                                          PyUnicode_FromString(path),
                                          PyBool_FromLong(Json_Ref_File));

            PyObject *pValue = PyObject_CallObject(pFunc, pArg);

            if (pValue != NULL)
            {
                Py_XDECREF(pFunc);
                Py_DECREF(pModule);

                parser.parameter_count = PyLong_AsLong(PyTuple_GetItem(pValue, 2));
                parser.Dict = (uint8_t *)PyUnicode_AsUTF8(PyTuple_GetItem(pValue, 1));
                return (uint8_t *)PyUnicode_AsUTF8(PyTuple_GetItem(pValue, 0));
            }
            else
            {
                PyErr_Print();
                fprintf(stderr, "Failed to call Python function %s.\n", function_name);
            }
        }
        else
        {
            if (PyErr_Occurred())
                PyErr_Print();
            fprintf(stderr, "Cannot find function '%s'.\n", function_name);
        }

        Py_XDECREF(pFunc);
        Py_DECREF(pModule);
    }
    else
    {
        PyErr_Print();
        fprintf(stderr, "Failed to load 'parser' module.\n");
    }

    Py_Finalize();
    return NULL;
}

/**
 * @brief Extract hexadecimal values from a TTL command string.
 * 
 * This function extracts the hexadecimal values from a TTL command 
 * string that contains a 'sendln' command.
 * 
 * @param ttl_data The TTL command string.
 * @param line The line number in the TTL file.
 * @return uint8_t* The extracted hexadecimal value, or NULL if extraction fails.
 */
uint8_t *extract_hex_values(const uint8_t *ttl_data, uint32_t line)
{

    static uint8_t hex_value[MAX_HEX_LENGTH + 1];
    uint8_t *token_sendln = strstr(ttl_data, "sendln '");

    if (token_sendln != NULL)
    {
        if (sscanf(token_sendln, "sendln '0x%8s", hex_value) == 1)
        {
            if ((hex_value[MAX_HEX_LENGTH - 1] == '\0') || (token_sendln[HEX_WITH_SENDLN_SIZE] != '\''))
            {
                printf("Warning: Unrecognized command or parameter  (line-%d) -> %s", line, ttl_data);
                return NULL;
            }
            hex_value[MAX_HEX_LENGTH] = '\0';
            return hex_value;
        }
    }
    else
    {
        if (token_sendln == NULL)
        {
            return NULL;
        }
        else
        {
            printf("Warning: Unrecognized command or parameter  (line-%d) -> '%s'\n", line, ttl_data);
            return NULL;
        }
    }
}

/**
 * @brief Identify a TTL command using a Python function call.
 * 
 * This function calls a Python function to validate and identify a TTL 
 * command, then updates the global command parameters accordingly.
 * 
 * @param command The TTL command to identify.
 * @param path The path to the reference file.
 * @param file_format The format of the reference file (JSON/YAML).
 * @param command_name The identified command name.
 * @return uint32_t SUCCESS if the command is valid, FAILURE otherwise.
 */
uint32_t command_identification(const uint8_t *command, const uint8_t *path, uint32_t file_format, uint8_t **command_name)
{

    *command_name = c_to_python_call("command_validation", command, false, "false", path, file_format);

    if (strstr(*command_name, "invalid"))
    {
        return FAILURE;
    }

    command_parameter_count = parser.parameter_count;
    return SUCCESS;
}

/**
 * @brief Identify parameters for a TTL command using a Python function call.
 * 
 * This function calls a Python function to extract bitfield parameters 
 * for a given TTL command.
 * 
 * @param command The TTL command.
 * @param parameter The parameter value to identify.
 * @param dictionary The dictionary to use for parameter identification.
 * @param Json_Ref_File The JSON reference file flag.
 * @return uint8_t* The identified parameter details.
 */
uint8_t *parameter_identification(const uint8_t *command, uint32_t parameter, const uint8_t *dictionary, bool Json_Ref_File)
{
    return c_to_python_call(
        "extract_bitfields_parameter",
        command,
        parameter,
        dictionary,
        "false",
        Json_Ref_File);
}

/**
 * @brief Print a double long line to an output file.
 * 
 * This function prints a line of '=' characters to the specified output 
 * file, to be used as a separator.
 * 
 * @param output_file The file to print the line to.
 * @param size The length of the line.
 */
void double_long_line(FILE *output_file, uint8_t size)
{
    for (uint32_t i = 0; i < size; i++)
    {
        fputc('=', output_file);
    }
    fputc('\n', output_file);
}

/**
 * @brief Initialize file metadata and write it to an output file.
 * 
 * This function initializes metadata for the input TTL file and writes 
 * it to the specified output file.
 * 
 * @param input_file The input TTL file.
 * @param output_file The output file to write metadata to.
 * @param Reference_File_Path The path to the reference file.
 * @param TTL_file The name of the TTL file.
 * @param now The current time.
 * @param day The current date.
 * @param author The author's name.
 * @param line_length The length of the separator line.
 * @return uint32_t SUCCESS if the operation is successful, FAILURE otherwise.
 */
uint32_t file_handle_init_meta_data(FILE *input_file, FILE *output_file, uint8_t *Reference_File_Path, const uint8_t *TTL_file, time_t now, uint8_t *day, const uint8_t *author, uint8_t line_length)
{

    if (!input_file || !output_file)
    {
        if (input_file == NULL)
        {
            perror("Error opening input file");
            fclose(output_file);
            fclose(input_file);
            return FAILURE;
        }
        else
        {
            perror("Error opening output file");
            fclose(output_file);
            return FAILURE;
        }
    }

    else
    {
        fseek(input_file, 0, SEEK_END);
        long file_size = ftell(input_file);

        if (file_size == 0)
        {
            printf("Error: The file '%s' is empty!\n", TTL_File);
            fclose(input_file);
            fclose(output_file);
            return FAILURE;
        }

        else
        {
            fseek(input_file, 0, SEEK_SET);

            if (Json_Ref_File == true)
            {
                strncpy(Reference_File_Path, Json_File, PATH_SIZE);
            }
            else
            {
                strncpy(Reference_File_Path, Yaml_File, PATH_SIZE);
            }
            if (author == NULL)
            {
                author = getenv("USERNAME");
            }

            double_long_line(output_file, line_length);
            fprintf(output_file, "Input TTL file : %s\n", TTL_file);
            fprintf(output_file, "Author : %s", author);
            time(&now);
            strftime(day, DATE_BUFFER_SIZE, "\t\t\t\t\t\tTime : %H:%M:%S \t\t\t\t\t Date : %d-%m-%Y", localtime(&now));
            fprintf(output_file, "%s\n", day);
            return SUCCESS;
        }
    }
}

/**
 * @brief Write TTL information to an output file.
 * 
 * This function writes TTL command or parameter details to the specified 
 * output file.
 * 
 * @param output_file The file to write the information to.
 * @param ttl_content The TTL content to write.
 * @param isCommand A flag indicating if the content is a command (true) or parameter (false).
 */
void write_ttl_info(FILE *output_file, uint8_t ttl_content[], bool isCommand)
{
    if (output_file != NULL && ttl_content != NULL && isCommand == true)
    {
        fprintf(output_file, "%35s : %s \n", "Command", ttl_content);
    }
    else if (output_file != NULL && ttl_content != NULL)
    {
        fprintf(output_file, "%s\n", ttl_content);
    }
    else
    {
        printf("Warning: Failed to write content in output.txt!\n");
    }
}

uint32_t main(void)
{

    time_t current_time;
    uint8_t current_day[DATE_BUFFER_SIZE];
    uint8_t Reference_File_Path[PATH_SIZE];
    uint8_t ttl_data[LINE_SIZE];
    uint8_t current_line = 0u;
    uint8_t print_line_length = 100u;
    const uint8_t *username = getenv("USER");

    FILE *input_file = fopen(TTL_File, "r");
    FILE *output_file = fopen(OUT_File, "w");

    file_handle_init_meta_data(input_file, output_file, Reference_File_Path, TTL_File, current_time, current_day, username, print_line_length);

    while (fgets(ttl_data, sizeof(ttl_data), input_file))
    {
        current_line++;
        if (ttl_data != NULL)
        {
            uint8_t *hex_value = extract_hex_values(ttl_data, current_line);
            if (hex_value != NULL)
            {
                strcpy(full_command, "0x");
                uint8_t Status = check_command(hex_value);
                if (Status == SUCCESS)
                {
                    uint8_t *command_name;

                    if (command_identification(full_command, Reference_File_Path, Json_Ref_File, &command_name) == FAILURE)
                    {
                        printf("%s is %s\n", full_command, command_name);
                        continue;
                    }

                    uint8_t command_details[DATE_BUFFER_SIZE];

                    if (current_parameter_count == 0 && command_parameter_count != 0)
                    {
                        printf("Warning: No parameter found for the command (line-%d) -> %s", current_line, ttl_data);
                    }
                    else
                    {
                        sprintf(command_details, "%s (%s)", command_name, full_command);
                        double_long_line(output_file, print_line_length);
                        write_ttl_info(output_file, command_details, isCommand);
                    }
                    uint32_t starting_param_count = 0;
                    if (current_parameter_count >= command_parameter_count)
                    {
                        starting_param_count = current_parameter_count - command_parameter_count;
                    }
                    for (uint32_t i = starting_param_count; i < current_parameter_count; i++)
                    {

                        if (parameter_buffer[i] != 0)
                        {

                            uint8_t *parameter_details;

                            parameter_details = parameter_identification(
                                full_command,
                                parameter_buffer[i],
                                parser.Dict,
                                Json_Ref_File);

                            write_ttl_info(output_file, parameter_details, false);
                            fputc('\n', output_file);
                        }
                    }
                }
                else if (Status == UNDEFINED)
                {
                    printf("Warning: Unrecognized command or parameter  (line-%d) -> %s", current_line, ttl_data);
                }
            }
        }
    }
    double_long_line(output_file, print_line_length);
    fclose(input_file);
    fclose(output_file);
    return 0;
}
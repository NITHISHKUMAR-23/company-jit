
import yaml
import json

def extract_bitfields_parameter(command_value, parameter_values, datas, path, file_format):
    """
    Extract bitfield parameters from the given data.
    
    This function extracts bitfield parameters from YAML or JSON data
    based on the specified file format. It processes the data to retrieve
    the bitfield information and constructs a detailed result.

    Parameters:
    command_value (str): The command value.
    parameter_values (int): The parameter values.
    datas (str): The data in YAML or JSON format.
    path (str): The path to the data file.
    file_format (int): The format of the data file (0 for YAML, 1 for JSON).

    Returns:
    tuple: A tuple containing the result string, the JSON string of the data,
           and a status code (1 for success).
    """
    result = ""
    parameter_number = (parameter_values >> 16) & 15  # Extract parameter number

    # Parse the data based on the file format (YAML or JSON)
    try:
        if file_format == 0:  # YAML
            data = yaml.safe_load(datas)
        elif file_format == 1:  # JSON
            data = json.loads(datas)
        else:
            return "Error: Unrecognized file format.", json.dumps({}), 0
    except (ValueError, yaml.YAMLError, json.JSONDecodeError) as e:
        print( f"Error reading data: {e}", json.dumps({}), 0)

    # Construct the key for the parameter and prepare the result string
    accessed_parameter = f"parameter{parameter_number}"
    result += f"\nParameter number: {parameter_number}\n\n"

    # Check if the accessed parameter exists in the "parameters" section of the data
    parameters = data.get("parameters", {})
    if accessed_parameter not in parameters:
        print (f"Error: {accessed_parameter} not found in parameters.", json.dumps(data), 0)

    accessed_param = parameters[accessed_parameter]

    # Check if the accessed parameter contains "bitfields"
    bitfields = accessed_param.get("bitfields")
    if isinstance(accessed_param, dict) and bitfields:
        for bitfield, bitfield_data in bitfields.items():
            if '-' in bitfield:  # If the bitfield is a range (e.g., '15-14')
                start, end = map(int, bitfield.split('-'))
                mask = (1 << (start - end + 1)) - 1  # Create the mask for the bit range
                extracted_bits_int = (parameter_values >> end) & mask  # Extract the bits
                extracted_bits_bin = bin(extracted_bits_int)[2:].zfill(start - end + 1)
                temp = bitfieldNameAndValue(data, accessed_parameter, bitfield, extracted_bits_bin)
                if temp:
                    result += temp + "\n"
            else:  # If the bitfield is a single bit (e.g., '0')
                extracted_bits_bin = (parameter_values >> int(bitfield)) & 1  # Extract the single bit
                temp = bitfieldNameAndValue(data, accessed_parameter, bitfield, str(extracted_bits_bin))
                if temp:
                    result += temp + "\n"
    else:
        print (f"Error: {accessed_parameter} is not a dictionary or missing 'bitfields'.", json.dumps(data), 0)

    return result, json.dumps(data), 1




def command_validation(command, parameter, dictionary, path, file_format):
    """
    Validate a command based on the provided dictionary.
    
    This function loads a command dictionary from a YAML or JSON file,
    validates the given command, and returns the command details if valid.

    Parameters:
    command (str): The command to validate.
    parameter (str): The parameter for the command.
    dictionary (str): The dictionary in YAML or JSON format.
    path (str): The path to the dictionary file.
    file_format (int): The format of the dictionary file (0 for YAML, 1 for JSON).

    Returns:
    tuple: A tuple containing the command name, the JSON string of the command details,
           and the number of parameters.
    """
    # Load the dictionary based on the file format
    try:
        with open(path, "r") as file:
            if file_format == 1:
                command_dict = json.load(file)  # Parse the JSON file content into a dictionary
            elif file_format == 0:
                command_dict = yaml.safe_load(file)  # Parse the YAML file content into a dictionary
            else:
                return "invalid command", "invalid dictionary", 0  # Handle invalid file format case
    except (FileNotFoundError, ValueError, yaml.YAMLError, json.JSONDecodeError):
        return "invalid command", "invalid dictionary", 0  # Handle file read/parse errors

    # Check if the command exists in the dictionary
    command_details = command_dict.get(command)
    if command_details:
        command_name = command_details.get("name", "unknown")
        command_parameters = command_details.get("parameters", [])
        # Return command name, full details as a JSON string, and number of parameters
        return command_name, json.dumps(command_details), len(command_parameters)
    else:
        return "invalid command", "invalid dictionary", 0  # Command not found in the dictionary




def bitfieldNameAndValue(data, parameter_input, bitfield, bit_value):
    """
    Extract the name and value of a bitfield.

    This function retrieves the name and value description of a bitfield
    from the provided data, and formats it as a string.

    Parameters:
    data (dict): The data containing the parameters and bitfields.
    parameter_input (str): The input parameter.
    bitfield (str): The bitfield to extract.
    bit_value (str): The value of the bitfield.

    Returns:
    str: A formatted string containing the bitfield name and value description.
    """
    bit_value = str(bit_value)

    # Navigate directly to the parameter section in the JSON structure
    parameter_data = data.get("parameters", {}).get(parameter_input, {})
    if not parameter_data:
        print (f"Error: '{parameter_input}' not found.")

    # Find the bitfield in the parameter's bitfields
    bitfield_data = parameter_data.get("bitfields", {}).get(bitfield, {}) or parameter_data.get("Bitfields", {}).get(bitfield, {})
    if not bitfield_data:
        print (f"Error: '{bitfield}' not found in '{parameter_input}'.")
    # Extract the name of the bitfield
    field_name = bitfield_data.get("name")
    if field_name == "Reserved":
        return None

    # Get the values dictionary, which contains the descriptions for different bit values
    values = bitfield_data.get("values", {}) or bitfield_data.get("Values", {})

    # Get the description for the provided bit_value, or use the default description if not provided
    value_description = values.get(bit_value, values.get("default"))
    if not value_description:
        print(f"Error: Bit value '{bit_value}' not found for bitfield '{bitfield}'.")

    # Return the formatted string with parameter and bitfield information on separate lines
    return f"-> {field_name:<41} : {value_description}"

 


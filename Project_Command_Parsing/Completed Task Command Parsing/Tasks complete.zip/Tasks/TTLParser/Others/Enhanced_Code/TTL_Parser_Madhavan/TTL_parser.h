#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stdint.h>
#include <python3.12/Python.h>
#include <time.h>

char *TTL_File = "D:\\my_final\\TTL_Input_file.ttl";
char *Json_File = "D:\\my_final\\Command_Reference_JSON.json";
char *Yaml_File = "D:\\my_final\\Command_Reference_YAML.yaml";
FILE *input_file;
FILE *output_file;
int reference_file_type = 1;
#define PATH_SIZE 256
#define Max_BUFFER_LENGTH 40
#define MAX_HEX_LENGTH 8
#define FULL_COMMAND_LENGTH 11

#define VALID_PARAMETER 0XF0000000
#define VALID_COMMAND 0XFFFF0000
#define VALID_FORMATE 0x20000000

uint32_t Parameter_buffer[Max_BUFFER_LENGTH];
uint8_t Parameter_count = 0;
uint8_t Current_Parameter_count = 0;
char Full_command[FULL_COMMAND_LENGTH] = "\0";


char* Dict;
 //If you need to store and pass any data, you can include it directly within the structure.

enum status
{
    SUCCESS,
    FAILURE,
    INVALID
};
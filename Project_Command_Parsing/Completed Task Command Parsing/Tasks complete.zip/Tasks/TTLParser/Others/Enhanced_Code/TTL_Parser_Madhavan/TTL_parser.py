import json

def python_fun(Full_command, Parameter_buffer, Reference_File_Path, reference_file_type, Current_Parameter_count):

    if reference_file_type == 1:    # Check if the file format is JSON (file_format == 1)"
        with open("D:\\my_final\\Command_Reference_JSON.json", "r") as file:
            dictc = json.load(file)

    if Full_command in dictc:
        if "parameters" in dictc[Full_command]:
            command_dict = dictc[Full_command]
        else:
            command_dict = dictc[Full_command]
    else:
        return ("invalid dictionary") 
    
    result = " "
    result+=command_dict["name"]+"("+Full_command+")"+"\n"

    try:
        Command_Parameter_count = len(command_dict["parameters"])
    except:
        return command_dict["name"]+"("+Full_command+")"+"\n"

    print(Current_Parameter_count)
    if((Current_Parameter_count - Command_Parameter_count) >= 0):
        i = Current_Parameter_count - Command_Parameter_count
    else:
        i=0

    for i in range (Current_Parameter_count):
        if Parameter_buffer[i] != 0:
            try:
                parameter_Number= int(((Parameter_buffer[i] )& 16711680)>>16)
                # Construct the key for the parameter and prepare the result string
                accessed_parameter= f"parameter{str(parameter_Number)}"
                parameter = f"{'parameter number':<41} : {str(parameter_Number)}"
                result += "\n" + parameter + "\n" + "\n"
                # Check if the accessed parameter exists in the "parameters" section of the data
                if accessed_parameter not in command_dict["parameters"]:
                    print(f"Error: {accessed_parameter} not found in parameters.")
                    return
                
                # Access the parameter's data
                accessed_param = command_dict["parameters"][accessed_parameter]
                
                # Check if the accessed parameter contains "bitfields"
                if isinstance(accessed_param, dict) and "bitfields" in accessed_param:
                    # Iterate over the bitfields in the accessed parameter
                    for bitfield, bitfield_data in accessed_param["bitfields"].items():
                        
                        # If the bitfield is a range (e.g., '15-14')
                        if '-' in bitfield:
                            # Split the bitfield range and create a mask to extract the specified bits
                            start, end = map(int, bitfield.split('-'))
                            mask = (1 << (start - end + 1)) - 1  # Create the mask for the bit range
                            extracted_bits_int = (Parameter_buffer[i] >> end) & mask  # Extract the bits
                            # Convert the extracted bits to binary
                            extracted_bits_bin = bin(extracted_bits_int)[2:].zfill(start - end + 1)
                            # Call the function to process the bitfield name and value
                            temp = bitfieldNameAndValue(command_dict, accessed_parameter, bitfield, extracted_bits_bin)
                            if temp:
                                result += temp + "\n"
                        else:  # If the bitfield is a single bit (e.g., '0')
                            extracted_bits_bin = (Parameter_buffer[i] >> int(bitfield)) & 1  # Extract the single bit
                            # Call the function to process the bitfield name and value
                            temp = bitfieldNameAndValue(command_dict, accessed_parameter, bitfield, extracted_bits_bin)
                            if temp:
                                result += temp + "\n"
                else:
                    # If the parameter doesn't contain 'bitfields', print an error
                    print(f"Error: {accessed_parameter} is not a dictionary or missing 'bitfields'.")
                    
            except KeyError as e:
                # Catch any KeyError (missing keys in the data) and print an error message
                print(f"Error: Missing expected key in JSON data: {e}")
            except ValueError as e:
                # Catch any ValueError (invalid values, such as non-integer values) and print an error message
                print(f"Error: Invalid value encountered. Ensure parameter values are in correct format. {e}")
    return result


def bitfieldNameAndValue(data, parameter_input, bitfield, bit_value):
    bit_value = str(bit_value)
    # Navigate directly to the parameter section in the JSON structure
    parameter_data = data.get("parameters", {}).get(parameter_input, {})
   
    if not parameter_data:
       
        print (f"Error: '{parameter_input}' not found.")
 
    parameter_name = parameter_input 
  
    # Find the bitfield in the parameter's bitfields
    bitfield_data = parameter_data.get("bitfields", {}).get(bitfield, {})
   
    if not bitfield_data:
        
        print (f"Error: '{bitfield}' not found in '{parameter_name}'.")
 
    # Extract the name of the bitfield
    field_name = bitfield_data.get("name")
    
    if field_name == "Reserved":
        return

    # Get the values dictionary, which contains the descriptions for different bit values
    values = bitfield_data.get("values", {})
   
    # Get the description for the provided bit_value, or use the default description if not provided
    value_description = values.get(bit_value, values.get("default"))

    # print(field_name," : ", value_description)

    if not value_description:
        
        print(f"Error: Bit value '{bit_value}' not found for bitfield '{bitfield}'.")
 
    # Return the formatted string with parameter and bitfield information on separate lines
    return f"{field_name:<41} : {value_description}"


    
    
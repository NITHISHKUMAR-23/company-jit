#include "TTL_parser.h"

char *c_to_python_call(char *function_name, char *command, int parameter_buffer[], char *path, uint32_t reference_file_type, int Current_Parameter_count)
{
    // Initialize the Python interpreter
    Py_Initialize();

    // Import the Python script
    PyObject *pName = PyUnicode_FromString("TTL_parser"); // Python module name
    PyObject *pModule = PyImport_Import(pName);
    Py_DECREF(pName);

    if (pModule != NULL)
    {
        // Get the function from the Python script
        PyObject *pFunc = PyObject_GetAttrString(pModule, function_name);

        if (pFunc && PyCallable_Check(pFunc))
        {
            // Call the Python function and get the result (JSON string)
            PyObject *py_list = PyList_New(Current_Parameter_count);
            if (py_list == NULL)
            {
                PyErr_Print();
                return NULL;
            }

            // Populate the Python list with integers from parameter_buffer
            for (int i = 0; i < Current_Parameter_count; ++i)
            {
                PyObject *py_int = PyLong_FromLong(parameter_buffer[i]);
                if (py_int == NULL)
                {
                    PyErr_Print();
                    Py_XDECREF(py_list);
                    return NULL;
                }
                PyList_SetItem(py_list, i, py_int); // PyList_SetItem steals the reference
            }
            PyObject *pArg = PyTuple_Pack(5,
                                          PyUnicode_FromString(command),
                                          py_list,
                                          PyUnicode_FromString(path),
                                          PyLong_FromLong(reference_file_type),
                                          PyLong_FromLong(Current_Parameter_count));

            PyObject *pValue = PyObject_CallObject(pFunc, pArg);

            // Handle the return value
            if (pValue!=NULL)
            {
                // If the result is a string, convert it to a C string
                char *result = (char*)PyUnicode_AsUTF8(pValue);
                if (result != NULL)
                {
                    
                    return result;
                }
                else
                {
                    PyErr_Print();
                }
            }
            // Clean up
            Py_XDECREF(pValue);
        }
        
        else
        {
            if (PyErr_Occurred())
                PyErr_Print();
            fprintf(stderr, "Cannot find function '%s'.\n", function_name);
        }

        Py_XDECREF(pFunc);
        Py_DECREF(pModule);
    }
    else
    {
        PyErr_Print();
        fprintf(stderr, "Failed to load 'parser' module.\n");
    }

    // Finalize the Python interpreter
    Py_Finalize();
    return NULL;
}

int check_command(int Hex_value)
{
    if ((Hex_value & VALID_COMMAND) == VALID_FORMATE)
    {
        char hex_string[MAX_HEX_LENGTH];
        sprintf(hex_string, "%X", Hex_value);
        strcat(Full_command, hex_string);
        // printf("Full_command: %s\n", Full_command);
        Current_Parameter_count = Parameter_count;
        Parameter_count = 0;
        return SUCCESS;
    }
    else if (((Hex_value & VALID_PARAMETER) == VALID_FORMATE))
    {
        Parameter_buffer[Parameter_count++] = Hex_value;
        return FAILURE;
    }
    else
    {
        Parameter_buffer[Parameter_count++] = (uint32_t)(0);
        return INVALID;
    }
    return FAILURE;
}

void InitializeMetaData(char *TTL_file, time_t now, char *day, char *author)
{

    fprintf(output_file, "Given TTL file : TTL_Input_file");
    time(&now);
    strftime(day, Max_BUFFER_LENGTH, "\t\tTime : %H:%M:%S \t\t Date : %d-%m-%Y", localtime(&now));
    fprintf(output_file, "%s\n", day);
    fprintf(output_file, "Author : %s\n", author);
}
uint32_t Extract_data(char *line)
{
    char line_copy[strlen(line) + 1];
    strcpy(line_copy, line);
    char *command = strtok(line_copy, "x");

    if (strcmp(command, "sendln '0") == 0)
    {
        char *str = strtok(NULL, "'");
        if (strlen(str) == 8)
        {
            for (int i = 0; i < MAX_HEX_LENGTH; i++)
            {
                if (((str[i] >= '0' && str[i] <= '9') || (str[i] >= 'A' && str[i] <= 'F') || (str[i] >= 'a' && str[i] <= 'f')) == 0)
                {
                    Parameter_buffer[Parameter_count++] = (uint32_t)(0);
                    return INVALID;
                }
            }
            int return_data = strtoul(str, NULL, 16);
            return return_data;
        }
        else
        {
            Parameter_buffer[Parameter_count++] = (uint32_t)(0);
            return INVALID;
        }
    }
    return SUCCESS;
}

uint8_t Write_Command(const char *Command_result)
{
    if (Command_result != NULL)
    {
        fprintf(output_file, "------------------------------------------------------------------------------------\n");
        printf("%s\n",Command_result);
        fprintf(output_file,"%s\n",Command_result);
        fprintf(output_file, "------------------------------------------------------------------------------------\n");
        return SUCCESS;
    }
    return FAILURE;
}


int main()
{
    time_t now;
    char day[Max_BUFFER_LENGTH];
    char *username = getenv("USER");
    if (username == NULL)
    {
        username = getenv("USERNAME");
    }
    input_file = fopen(TTL_File, "r");
    if (input_file == NULL)
    {
        printf("Input file is not open");
        exit(0);
    }

    output_file = fopen("output.txt", "w");
    if (output_file == NULL)
    {
        printf("output_file is not open");
        exit(0);
    }

    char Reference_File_Path[PATH_SIZE];

    if (reference_file_type == true)
        strncpy(Reference_File_Path, Json_File, PATH_SIZE);
    else
        strncpy(Reference_File_Path, Yaml_File, PATH_SIZE);

    InitializeMetaData(TTL_File, now, day, username);
    // printf("%s\n",Reference_File_Path);
    char line[Max_BUFFER_LENGTH];
    while (fgets(line, sizeof(line), input_file) != NULL)
    {
        int Hex_Data = Extract_data(line);
        if (Hex_Data > INVALID)
        {
            strcpy(Full_command, "0x");
            int status = check_command(Hex_Data);
            if (status == SUCCESS)
            {
                // c_to_python_call
                //  (char *function_name, char *command, int parameter_buffer[], char *path, uint32_t reference_file_type,int current_parameter_count)
                // printf(Full_command);
                char *Command_result = (char*)c_to_python_call("python_fun", Full_command, Parameter_buffer, Reference_File_Path, reference_file_type, Current_Parameter_count);
                uint8_t written_status = Write_Command(Command_result);
                if(written_status == FAILURE)
                {
                    printf("no return for command %s",Full_command);
                }
            }
        }
    }
    return SUCCESS;
    fclose(input_file);
    fclose(output_file);
}
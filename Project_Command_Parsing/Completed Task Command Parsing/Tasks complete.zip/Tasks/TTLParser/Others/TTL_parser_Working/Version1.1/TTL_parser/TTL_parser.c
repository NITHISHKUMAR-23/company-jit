#include "TTL_parser.h"

/******************************************************************************************************************************************
*  Project          :   TTL Parser 
*  Organization     :   Jasmin Infotech Private Limited, Chennai
*  File Name        :   TTL_parser.c
*  Description      :   This file implements various functions for parsing TTL  commands, interacting with                       
*                       Python scripts, validating commands, and managing file metadata. It establishes communication between C and                        
*                       Python for executing specific commands and handles the extraction and processing of hexadecimal data from TTL                       
*                       input. Functions are provided for managing command buffers,writing output, and handling file metadata.
*                       
******************************************************************************************************************************************/



/******************************************************************************************************************************************
 *  Module Name        : c_to_python_call
 *  Functionality      : Establishes a communication bridge between the C program and a Python script. It initializes the Python
 *                       interpreter, imports a Python module, and invokes a specified Python function. This function passes parameters 
 *                       (command, parameter list, file path, and file type) from the C code to the Python script and retrieves the result.
 *  Input Parameters   :
 *                       - function_name (char*)       : The name of the Python function to invoke.
 *                       - command (char*)             : Command string to be processed by the Python function.
 *                       - parameter_buffer (int[])    : Array of integers representing parameters to pass to the Python function.
 *                       - path (char*)                : File path (JSON/YAML) to be used by the Python function.
 *                       - reference_file_type (uint32_t): Indicator of the reference file type (JSON/YAML).
 *                       - Current_Parameter_count (int): Number of parameters in `parameter_buffer`.
 *  Output Parameters  : 
 *                       - Returns a JSON string (char*) containing the result of the Python function.
 ******************************************************************************************************************************************/

uint8_t *c_to_python_call(uint8_t *function_name, uint8_t *command, uint32_t parameter_buffer[], uint8_t *path, uint32_t reference_file_type, uint32_t current_parameter_count)
{

    Py_Initialize();
    PyObject *pName = PyUnicode_FromString("TTL_parser");
    PyObject *pModule = PyImport_Import(pName);
    Py_DECREF(pName);

    if (pModule != NULL)
    {
        // Get the function from the Python script
        PyObject *pFunc = PyObject_GetAttrString(pModule, function_name);

        if (pFunc && PyCallable_Check(pFunc))
        {
            // Call the Python function and get the result (JSON string)
            PyObject *py_list = PyList_New(current_parameter_count);
            if (py_list == NULL)
            {
                PyErr_Print();
                return NULL;
            }
            // Populate the Python list with integers from parameter_buffer
            for (uint32_t i = 0; i < current_parameter_count; ++i)
            {
                PyObject *py_int = PyLong_FromLong(parameter_buffer[i]);
                if (py_int == NULL)
                {
                    PyErr_Print();
                    Py_XDECREF(py_list);
                    return NULL;
                }
                PyList_SetItem(py_list, i, py_int); // PyList_SetItem steals the reference
            }
            PyObject *pArg = PyTuple_Pack(5,
                                          PyUnicode_FromString(command),
                                          py_list,
                                          PyUnicode_FromString(path),
                                          PyLong_FromLong(reference_file_type),
                                          PyLong_FromLong(current_parameter_count));

            PyObject *pValue = PyObject_CallObject(pFunc, pArg);

            // Handle the return value
            if (pValue != NULL)
            {
                // If the result is a string, convert it to a C string
                uint8_t *result = (uint8_t *)PyUnicode_AsUTF8(pValue);
                if (result != NULL)
                {

                    return result;
                }
                else
                {
                    PyErr_Print();
                }
            }
            // Clean up
            Py_XDECREF(pValue);
        }

        else
        {
            if (PyErr_Occurred())
                PyErr_Print();
            fprintf(stderr, "Cannot find function '%s'.\n", function_name);
        }

        Py_XDECREF(pFunc);
        Py_DECREF(pModule);
    }
    else
    {
        PyErr_Print();
        fprintf(stderr, "Failed to load 'parser' module.\n");
    }

    // Finalize the Python interpreter
    Py_Finalize();
    return NULL;
}

/******************************************************************************************************************************************
 *  Module Name        : check_command
 *  Functionality      : This module parses a given TTL value to identify whether it is a valid command or parameter. If valid,
 *                       it stores the command or parameter in appropriate buffers and returns a success status. It handles the
 *                       detection of invalid commands or parameters and ensures proper buffer management.
 *  Input Parameters   :
 *                       - ttl_value (uint32_t) : TTL value to be checked.
 *  Output Parameters  : 
 *                       - Returns (uint32_t) : 
 *                         - SUCCESS (uint32_t) : If the command was successfully processed.
 *                         - FAILURE (uint32_t) : If a parameter was successfully added to the buffer.
 *                         - INVALID (uint32_t) : If the TTL value is invalid (command or parameter).
 ******************************************************************************************************************************************/

uint32_t check_command(uint32_t ttl_value)
{
    if (((ttl_value >> CHECK_28_31_BIT) & BIT_ACCESS_4) != VALID_COMMAND_OR_PARAM)
    {
        // Invalid command, set parameter buffer to 0 and return UNDEFINED
        parameter_buffer[parameter_count++] = (uint32_t)(0);
        return INVALID;
    }

    uint32_t check_cmd_or_param = (ttl_value >> CHECK_16_23_BIT) & BIT_ACCESS_8;

    if (check_cmd_or_param == 0)
    {
        // Store the command in full_command and reset the parameter count
        uint8_t hex_string[MAX_HEX_LENGTH];
        sprintf(hex_string, "%X", ttl_value);
        strcat(full_command, hex_string);
        current_parameter_count = parameter_count;
        parameter_count = 0;
        return SUCCESS;
    }
    else if ((check_cmd_or_param > 0) || (check_cmd_or_param > 0)) // If the value is between 1 and 15, it's a parameter
    {
        // If it's a parameter, store it in the parameter buffer
        parameter_buffer[parameter_count++] = ttl_value;
        return FAILURE; // Valid parameter
    }
    else // Invalid value for command/parameter
    {
        // Reset parameter buffer and return UNDEFINED
        parameter_buffer[parameter_count++] = (uint32_t)(0);
        return INVALID;
    }
    return FAILURE;
}

/******************************************************************************************************************************************
 *  Module Name        : double_long_line
 *  Functionality      : This module writes a line of equal signs (`=`) to the output file, useful for separating sections 
 *                       of the output with a visual divider. The number of equal signs printed is determined by the given size.
 *  Input Parameters   :
 *                       - output_file (FILE*) : Pointer to the file where the line of equal signs will be written.
 *                       - size (uint8_t) : The number of equal signs to print in the line.
 *  Output Parameters  : 
 *                       - None (void function).
 ******************************************************************************************************************************************/

void double_long_line(FILE *output_file, uint8_t size)
{
    for (uint32_t i = 0; i < size; i++)
    {
        fputc('=', output_file);
    }
    fputc('\n', output_file);
}

/******************************************************************************************************************************************
 *  Module Name        : file_handle_init_meta_data
 *  Functionality      : This module initializes the metadata for the input and output files. It validates the files, checks the 
 *                       file extension, handles errors, and writes metadata information (including file paths, author, and date)
 *                       to the output file.
 *  Input Parameters   :
 *                       - input_file (FILE*) : Pointer to the opened input file (TTL file).
 *                       - output_file (FILE*) : Pointer to the opened output file.
 *                       - Reference_File_Path (uint8_t*) : Path to the reference file.
 *                       - TTL_file (uint8_t*) : Name of the TTL file being processed.
 *                       - now (time_t) : Current time used for date formatting.
 *                       - day (uint8_t*) : String to hold the formatted current day and time.
 *                       - author (uint8_t*) : Name of the author (user executing the program).
 *                       - line_length (uint8_t) : Line length to format output.
 *                       - extension (uint8_t*) : File extension of the reference file (e.g., ".json", ".yaml").
 *  Output Parameters  : 
 *                       - Returns (uint32_t) : SUCCESS if initialization is successful, FAILURE if an error occurs.
 //******************************************************************************************************************************************/

uint32_t file_handle_init_meta_data(FILE *input_file, FILE *output_file, uint8_t *Reference_File_Path, const uint8_t *TTL_file, time_t now, uint8_t *day, const uint8_t *author, uint8_t line_length, const uint8_t *extension)
{
    {

        if (!input_file || !output_file)
        {
            if (input_file == NULL)
            {
                perror("Error opening input file");
                fclose(output_file);
                fclose(input_file);
                return FAILURE;
            }
            else
            {
                perror("Error opening output file");
                fclose(output_file);
                return FAILURE;
            }
        }

        else
        {
            fseek(input_file, 0, SEEK_END);
            long file_size = ftell(input_file);

            if (file_size == 0)
            {
                printf("Error: The file '%s' is empty!\n", TTL_file);
                fclose(input_file);
                fclose(output_file);
                return FAILURE;
            }

            else
            {
                fseek(input_file, 0, SEEK_SET);

                if (extension != NULL)
                {
                    if (strncmp(extension, ".json",FILE_EXTENSION_SIZE) == 0)
                    {
                        reference_file_type = JSON;
                    }
                    else if (strncmp(extension, ".yaml",FILE_EXTENSION_SIZE) == 0 || strncmp(extension, ".yml",FILE_EXTENSION_SIZE) == 0)
                    {
                        reference_file_type = YAML;
                    }
                    else
                    {
                        perror("Error: Both files must be either .json or .yaml/.yml\n");
                        return EXIT_FAILURE;
                    }
                }
                else
                {
                    perror("Error: There is no any file extension for the reference file\n");
                    return EXIT_FAILURE;
                }

                if (author == NULL)
                {
                    author = getenv("USERNAME");
                }

                double_long_line(output_file, line_length);
                fprintf(output_file, "Input TTL file : %s\n", TTL_file);
                fprintf(output_file, "Author : %s", author);
                time(&now);
                strftime(day, DATE_BUFFER_SIZE, "\t\t\t\t\t\tTime : %H:%M:%S \t\t\t\t\t Date : %d-%m-%Y", localtime(&now));
                fprintf(output_file, "%s\n", day);
                return SUCCESS;
            }
        }
    }
}

/******************************************************************************************************************************************
 *  Module Name        : extract_hex
 *  Functionality      : This module extracts a valid 8-character hexadecimal value from a given TTL data string. It parses 
 *                       the string and checks for validity (i.e., ensures the string is a valid hexadecimal number). If valid, 
 *                       the hexadecimal value is converted and returned. If invalid, an error flag is returned.
 *  Input Parameters   :
 *                       - ttl_data (uint8_t*) : String containing TTL data to be parsed for hexadecimal values.
 *  Output Parameters  : 
 *                       - Returns (uint32_t) : 
 *                         - Valid hexadecimal value (uint32_t) : If the data is valid and properly formatted.
 *                         - INVALID (uint32_t) : If the data is invalid or improperly formatted.
 ******************************************************************************************************************************************/

uint32_t extract_hex(uint8_t *ttl_data)
{
    uint8_t ttl_data_copy[strlen(ttl_data) + 1];
    strcpy(ttl_data_copy, ttl_data);
    uint8_t *command = strtok(ttl_data_copy, "x");

    if (strncmp(command, "sendln '0",FULL_COMMAND_LENGTH) == 0)
    {
        uint8_t *str = strtok(NULL, "'");
        if (strlen(str) == MAX_HEX_LENGTH)
        {
            for (uint32_t i = 0; i < MAX_HEX_LENGTH; i++)
            {
                if (!isxdigit(str[i]))
                {
                    parameter_buffer[parameter_count++] = (uint32_t)(0);
                    return INVALID;
                }
            }
            uint32_t return_data = strtoul(str, NULL, HEX_BASE);
            return return_data;
        }
        else
        {
            parameter_buffer[parameter_count++] = (uint32_t)(0);
            return INVALID;
        }
    }
}

/******************************************************************************************************************************************
 *  Module Name        : write_ttl_info
 *  Functionality      : This module writes the processed TTL command result to the output file. It formats and prints the 
 *                       result with proper separators. If the result is valid, it writes the result to the output file.
 *  Input Parameters   :
 *                       - output_file (FILE*) : Pointer to the output file where the result will be written.
 *                       - line_length (int8_t) : Length of the line for proper formatting.
 *                       - Command_result (uint8_t*) : Processed command result to be written to the output file.
 *  Output Parameters  : 
 *                       - Returns (uint8_t) : SUCCESS if the result is written successfully, FAILURE if it fails.
 ******************************************************************************************************************************************/

uint8_t write_ttl_info(FILE *output_file, int8_t line_length, uint8_t *Command_result)
{
    if (Command_result != NULL && output_file != NULL)
    {
        double_long_line(output_file, line_length);
        fprintf(output_file, "%s\n", Command_result);
        return SUCCESS;
    }
    else{
        printf("Failed to write the ttl information\n");
        return FAILURE;
    }
    
}

/******************************************************************************************************************************************
 *  Module Name        : main
 *  Functionality      : This is the main entry point of the program. It processes the input TTL file, extracts command and 
 *                       parameter data, and passes the data to a Python function for further processing. It handles input/output 
 *                       file handling, error management, and writes the results to the output file. It performs the necessary 
 *                       checks to validate commands and parameters before calling the Python function.
 *  Input Parameters   :
 *                       - argc (int32_t) : Argument count indicating the number of command line arguments.
 *                       - argv (uint8_t*) : Array of strings containing the command line arguments (TTL file, output file, reference file).
 *  Output Parameters  : 
 *                       - Returns (uint32_t) : 
 *                         - SUCCESS (int) : If the program runs successfully.
 *                         - EXIT_FAILURE (int) : If the program encounters an error (e.g., file handling issues).
 ******************************************************************************************************************************************/
uint32_t main(uint32_t argc, uint8_t *argv[])
{
    time_t current_time;
    uint8_t current_day[DATE_BUFFER_SIZE];
    uint8_t ttl_data[TTL_DATA_SIZE];
    uint8_t current_line = 0u;
    uint8_t print_line_length = 100u;
    const uint8_t *username = getenv("USER");
    uint8_t command_details[DATE_BUFFER_SIZE];
    uint8_t *TTL_File;
    uint8_t *OUT_File;
    uint8_t *Reference_File_Path;

    FILE *input_file;
    FILE *output_file;

    if (argc != ARGUMENT_SIZE)
    {
        fprintf(stderr, "Usage: %s <TTL_File> <OUT_File> <Reference_File>\n", argv[0]);
        return EXIT_FAILURE;
    }

    // Get file paths from the command line arguments
    TTL_File = argv[1];
    OUT_File = argv[2];
    Reference_File_Path = argv[3];

    input_file = fopen(TTL_File, "r");
    output_file = fopen(OUT_File, "w");
    const uint8_t *extension = strrchr(Reference_File_Path, '.'); // Find last occurrence of '.'

    file_handle_init_meta_data(input_file, output_file, Reference_File_Path, TTL_File, current_time, current_day, username, print_line_length, extension);

    while (fgets(ttl_data, sizeof(ttl_data), input_file) != NULL)
    {
        int hex_data = extract_hex(ttl_data);
        if (hex_data > INVALID)
        {

            strcpy(full_command, "0x");

            uint32_t status = check_command(hex_data);

            if (status == SUCCESS)
            {
                uint8_t *Command_result = (uint8_t *)c_to_python_call("extract_ttl_details", full_command, parameter_buffer, Reference_File_Path, reference_file_type, current_parameter_count);
                uint8_t written_status = write_ttl_info(output_file, print_line_length, Command_result);
                if (written_status == FAILURE)
                {
                    printf("no return for command %s", full_command);
                }
            }
        }
    }
    double_long_line(output_file, print_line_length);
    fclose(input_file);
    fclose(output_file);
    return SUCCESS;
}
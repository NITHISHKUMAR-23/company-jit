import yaml
import json

def command_validation(command,parameter,parameter_no,dictionary,path,file_format):

    if file_format == 1:
        with open(path, "r") as file:
            dict = json.load(file)
    elif file_format == 0:
        with open(path, "r") as file:
            dict = yaml.safe_load(file)

    if command in dict:
        return (dict[command]["name"], json.dumps(dict[command]), len(dict[command]["parameters"]))  # Convert dictionary to JSON strin
    else:
        return "i"
    
                                # command, parameter, parser.parameter_count, parser.Dict, "false", false)
def extract_bitfields_parameter(command_value, parameter_values, parameter_number, datas, path, file_format):
    data = json.loads(datas)

    try:
        # Convert parameter value from hex to integer
        parameter_value = int(str(parameter_values), 16)
 
        # Construct the parameter key name
        accessed_parameter = f"parameter{str(parameter_number)}"
        
        # Debugging step: Check if accessed_parameter exists and its type
        if accessed_parameter not in data["parameters"]:
            print(f"Error: {accessed_parameter} not found in parameters.")
            return
        else:
            print(f"Type of {accessed_parameter}: {type(data['parameters'][accessed_parameter])}")
        
        accessed_param = data["parameters"][accessed_parameter]
        
        if isinstance(accessed_param, dict) and "bitfields" in accessed_param:
            # Iterate through bitfields and extract values
            for bitfield, bitfield_data in accessed_param["bitfields"].items():
                if '-' in bitfield:  # Bit range like '15-14'
                    start, end = map(int, bitfield.split('-'))
                    mask = (1 << (start - end + 1)) - 1  # Create a mask to extract bits in the range
                    extracted_bits_int = (parameter_value >> end) & mask
                    extracted_bits_bin = bin(extracted_bits_int)[2:].zfill(start - end + 1)
                    print(data, accessed_parameter, bitfield, extracted_bits_bin)

                else:  # Single bit like '0'
                    extracted_bits_bin = (parameter_value >> int(bitfield)) & 1
                    print(data, accessed_parameter, bitfield, extracted_bits_bin)
        else:
            print(f"Error: {accessed_parameter} is not a dictionary or missing 'bitfields'.")
               
    except KeyError as e:
        print(f"Error: Missing expected key in JSON data: {e}")
    except ValueError as e:
        print(f"Error: Invalid value encountered. Ensure parameter values are in correct format. {e}")


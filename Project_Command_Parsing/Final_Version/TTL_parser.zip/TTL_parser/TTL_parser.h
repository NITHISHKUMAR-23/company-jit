#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stdint.h>
#include <ctype.h>
#include <stdarg.h>
#include <python3.12/Python.h>
#include <time.h>

#define PATH_SIZE 256
#define Max_BUFFER_LENGTH 40
#define MAX_HEX_LENGTH 8
#define FULL_COMMAND_LENGTH 11

uint8_t reference_file_type;
uint32_t Parameter_buffer[Max_BUFFER_LENGTH];
uint8_t Parameter_count = 0;
uint32_t Current_Parameter_count = 0;
char Full_command[FULL_COMMAND_LENGTH];
FILE *input_file;
FILE *output_file;

char *TTL_File;
char *OUT_File;
char *Reference_File_Path;

enum status
{
    SUCCESS,
    FAILURE,
    INVALID
};

enum file_type
{
    YAML,
    JSON
};

#define CHECK_28_31_BIT 28
#define CHECK_16_23_BIT 16
#define BIT_ACCESS_8 255
#define BIT_ACCESS_4 127
#define VALID_COMMAND_OR_PARAM 2
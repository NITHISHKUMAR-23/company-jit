#include "TTL_parser.h"

char *c_to_python_call(char *function_name, char *command, int parameter_buffer[], char *path, uint32_t reference_file_type, int Current_Parameter_count)
{
    // printf("ctypecall%d\n",reference_file_type);
    // Initialize the Python interpreter
    Py_Initialize();

    // Import the Python script
    PyObject *pName = PyUnicode_FromString("TTL_parser"); // Python module name
    PyObject *pModule = PyImport_Import(pName);
    Py_DECREF(pName);

    if (pModule != NULL)
    {
        // Get the function from the Python script
        PyObject *pFunc = PyObject_GetAttrString(pModule, function_name);

        if (pFunc && PyCallable_Check(pFunc))
        {
            // Call the Python function and get the result (JSON string)
            PyObject *py_list = PyList_New(Current_Parameter_count);
            if (py_list == NULL)
            {
                PyErr_Print();
                return NULL;
            }

            // Populate the Python list with integers from parameter_buffer
            for (int i = 0; i < Current_Parameter_count; ++i)
            {
                PyObject *py_int = PyLong_FromLong(parameter_buffer[i]);
                if (py_int == NULL)
                {
                    PyErr_Print();
                    Py_XDECREF(py_list);
                    return NULL;
                }
                PyList_SetItem(py_list, i, py_int); // PyList_SetItem steals the reference
            }
            PyObject *pArg = PyTuple_Pack(5,
                                          PyUnicode_FromString(command),
                                          py_list,
                                          PyUnicode_FromString(path),
                                          PyLong_FromLong(reference_file_type),
                                          PyLong_FromLong(Current_Parameter_count));

            PyObject *pValue = PyObject_CallObject(pFunc, pArg);

            // Handle the return value
            if (pValue!=NULL)
            {
                // If the result is a string, convert it to a C string
                char *result = (char*)PyUnicode_AsUTF8(pValue);
                if (result != NULL)
                {
                    
                    return result;
                }
                else
                {
                    PyErr_Print();
                }
            }
            // Clean up
            Py_XDECREF(pValue);
        }
        
        else
        {
            if (PyErr_Occurred())
                PyErr_Print();
            fprintf(stderr, "Cannot find function '%s'.\n", function_name);
        }

        Py_XDECREF(pFunc);
        Py_DECREF(pModule);
    }
    else
    {
        PyErr_Print();
        fprintf(stderr, "Failed to load 'parser' module.\n");
    }

    // Finalize the Python interpreter
    Py_Finalize();
    return NULL;
}



int check_command(int ttl_value)
{
        if(((ttl_value>>CHECK_28_31_BIT)&BIT_ACCESS_4) != VALID_COMMAND_OR_PARAM)
    {
        // Invalid command, set parameter buffer to 0 and return UNDEFINED
        Parameter_buffer[Parameter_count++] = (uint32_t)(0);
        return INVALID;
    }
 
    int check_cmd_or_param = (ttl_value>>CHECK_16_23_BIT) & BIT_ACCESS_8;
 
    if(check_cmd_or_param==0)
    {
        // Store the command in Full_command and reset the parameter count
        char hex_string[MAX_HEX_LENGTH];
        sprintf(hex_string, "%X", ttl_value);
        strcat(Full_command, hex_string);
        Current_Parameter_count = Parameter_count;
        Parameter_count = 0;
        return SUCCESS;
    }
    else if ((check_cmd_or_param > 0) || (check_cmd_or_param > 0))  // If the value is between 1 and 15, it's a parameter
    {
        // If it's a parameter, store it in the parameter buffer
        Parameter_buffer[Parameter_count++] = ttl_value;
        return FAILURE;  // Valid parameter
    }
    else  // Invalid value for command/parameter
    {
        // Reset parameter buffer and return UNDEFINED
        Parameter_buffer[Parameter_count++] = (uint32_t)(0);
        return INVALID;
    }
    return FAILURE;

}

void InitializeMetaData(char *TTL_file, time_t now, char *day, char *author)
{

    fprintf(output_file, "Given TTL file : TTL_Input_file");
    time(&now);
    strftime(day, Max_BUFFER_LENGTH, "\t\tTime : %H:%M:%S \t\t Date : %d-%m-%Y", localtime(&now));
    fprintf(output_file, "%s\n", day);
    fprintf(output_file, "Author : %s\n", author);
    fprintf(output_file, "------------------------------------------------------------------------------------\n");
}

uint32_t Extract_data(char *line)
{
    char line_copy[strlen(line) + 1];
    strcpy(line_copy, line);
    char *command = strtok(line_copy, "x");

    if (strcmp(command, "sendln '0") == 0)
    {
        char *str = strtok(NULL, "'");
        if (strlen(str) == 8)
        {
            for (int i = 0; i < MAX_HEX_LENGTH; i++)
            {
                if (!isxdigit(str[i]))
                {
                    Parameter_buffer[Parameter_count++] = (uint32_t)(0);
                    return INVALID;
                }
            }
            int return_data = strtoul(str, NULL, 16);
            return return_data;
        }
        else
        {
            Parameter_buffer[Parameter_count++] = (uint32_t)(0);
            return INVALID;
        }
    }
}

uint8_t Write_Command(const char *Command_result)
{
    if (Command_result != NULL)
    {
        fprintf(output_file,"%s\n",Command_result);
        fprintf(output_file, "------------------------------------------------------------------------------------\n");
        return SUCCESS;
    }
    return FAILURE;
}


int main(int argc,char* argv[])
{
    time_t now;
    char day[Max_BUFFER_LENGTH];
    char *username = getenv("USER");
    if (username == NULL)
    {
        username = getenv("USERNAME");
    }
    if (argc != 4)
    {
        fprintf(stderr, "Usage: %s <TTL_File> <OUT_File> <Reference_File>\n", argv[0]);
        return EXIT_FAILURE;
    }

    // Get file paths from the command line arguments
    TTL_File = argv[1];
    OUT_File = argv[2];
    Reference_File_Path = argv[3];
    const char *extension = strrchr(Reference_File_Path, '.');  // Find last occurrence of '.'
    
    if (extension != NULL)
    {
        if (strcmp(extension, ".json") == 0)
        {


            reference_file_type = JSON;
        }
        else if (strcmp(extension, ".yaml") == 0 || strcmp(extension, ".yml") == 0)
        {
            reference_file_type = YAML;
        }
        else
        {
            perror("Error: Both files must be either .json or .yaml/.yml\n");
            return EXIT_FAILURE;
        }
    }
    else
    {
        perror("Error: There is no any file extension for the reference file\n");
        return EXIT_FAILURE;
    }
    input_file = fopen(TTL_File, "r");
    if (input_file == NULL)
    {
        perror("Input file is not open");
        fclose(input_file);
        return EXIT_FAILURE;
    }

    fseek(input_file, 0, SEEK_END);
    long file_size = ftell(input_file); // Get the size of the file


    fseek(input_file, 0, SEEK_SET);

    // If the file size is zero, the file is empty
    if (file_size == 0)
    {
        perror("Input file is empty\n");
        fclose(input_file);
        return EXIT_FAILURE;
    }
    
    output_file = fopen(OUT_File, "w");
    if (output_file == NULL)
    {
        perror("output_file is not open");
        fclose(output_file);
        return EXIT_FAILURE;
    }

    InitializeMetaData(TTL_File, now, day, username);

    char line[Max_BUFFER_LENGTH];
    
    while (fgets(line, sizeof(line), input_file) != NULL)
    {
        int Hex_Data = Extract_data(line);
        if (Hex_Data > INVALID)
        {

            strcpy(Full_command, "0x");

            int status = check_command(Hex_Data);

            if (status == SUCCESS)
            {
                char *Command_result = (char*)c_to_python_call("python_fun", Full_command, Parameter_buffer, Reference_File_Path, reference_file_type, Current_Parameter_count);
                uint8_t written_status = Write_Command(Command_result);
                if(written_status == FAILURE)
                {
                    printf("no return for command %s",Full_command);
                }
            }
        }
    }
    fclose(input_file);
    fclose(output_file);
    return SUCCESS;
}
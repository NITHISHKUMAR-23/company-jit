################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.9.1/SHARC/lib/src/services/Source/pwr/adi_pwr.c 

SRC_OBJS += \
./system/services/pwr/adi_pwr.doj 

C_DEPS += \
./system/services/pwr/adi_pwr.d 


# Each subdirectory must supply rules for building sources it contributes
system/services/pwr/adi_pwr.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.9.1/SHARC/lib/src/services/Source/pwr/adi_pwr.c
	@echo 'Building file: $<'
	@echo 'Invoking: CrossCore SHARC C/C++ Compiler'
	cc21k -c -file-attr ProjectName="21569_init" -proc ADSP-21569 -flags-compiler --no_wrap_diagnostics -si-revision any -g -DCORE0 -D_DEBUG @includes-a20828c440f19f28387b0febcb1054cb.txt -structs-do-not-overlap -no-const-strings -no-multiline -misra -misra-strict -misra-no-cross-module -misra-no-runtime -misra-testing -misra-suppress-advisory -double-size-32 -char-size-8 -swc -gnu-style-dependencies -MD -Mo "system/services/pwr/adi_pwr.d" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '



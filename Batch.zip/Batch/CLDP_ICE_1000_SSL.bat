"C:\Analog Devices\CrossCore Embedded Studio 2.11.1\cldp.exe" -proc ADSP-21593 -core 0 -emu 1000 -driver is25lp512m_dpia_21593_Core1_EZKIT.dxe -cmd prog -offset 0x00000 -erase affected -format hex -file AD_Talkthrough_I2S_21593_Core1.ldr
@pause



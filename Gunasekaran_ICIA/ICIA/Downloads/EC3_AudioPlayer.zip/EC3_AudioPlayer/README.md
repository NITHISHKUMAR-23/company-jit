# EC3 Audio Player GUI (RPi → AVR8 → AVR9 → Output)

A standalone web GUI (separate from your existing AVR9 UART-command
GUI on port 5500) that lets you play `.eac3` files from an iPad
browser. The RPi streams the file to `mpv`, which sends the audio out
over **HDMI as a compressed bitstream** ("passthrough") — AVR8 does
the actual EAC3 decoding downstream. The RPi itself never decodes to
PCM.

## 1. Install on the RPi

```bash
sudo apt update
sudo apt install -y mpv python3-pip
cd EC3_AudioPlayer
pip3 install -r requirements.txt
```

## 2. Audio device

`player.py` sets:

```python
HDMI_AUDIO_DEVICE = "alsa/default"
```

This is what's confirmed working on the target Pi + AVR8 setup. If
you move to different hardware and audio goes silent, find the real
card name with `aplay -l` and point `HDMI_AUDIO_DEVICE` at the
matching ALSA device instead (e.g. `alsa/iec958:CARD=vc4hdmi0,DEV=0`
or `alsa/hw:vc4hdmi0,0`) — see `SETUP_AND_DIAGNOSTICS.md` for the
full troubleshooting steps.

> **Passthrough note:** For EAC3 bitstream passthrough to work over
> HDMI, AVR8 must advertise EAC3 support in its EDID, and the Pi's
> HDMI audio config needs to be in a mode that doesn't force
> stereo/PCM-only. If audio comes out as silence or noise instead of
> clean sound, that's the first place to check — not the Flask app.

## 3. Run

```bash
python3 main.py
```

The GUI is served at `http://<RPi-IP>:5600` — open that from Safari
on the iPad (same Wi-Fi network as the RPi, same idea as your existing
AVR9 command GUI on port 5500).

## 4. Using it

- Tracks are read live from a folder on the Pi (default
  `/home/jasminuser/dolby`) — tap the gear icon next to the folder
  path shown at the top of the player card to change it.
- **Tap a track** in the list to play it directly.
- **Transport row**: Previous / Play-Pause / Next / Stop.
- Playback runs straight through the folder in order, start to end,
  and stops after the last track — unless Repeat is on.
- **Repeat**: tap to toggle Off ↔ One. (Repeat One is the mode used
  for demos, so it's reachable in a single tap.)
- The equalizer bars animate while something is playing — this is a
  **decorative animation**, not a live level meter. Because audio
  leaves the Pi as an untouched EAC3 bitstream (for AVR8 to decode),
  there's no PCM signal on the Pi side to measure real levels from.

## Files

```
EC3_AudioPlayer/
├── main.py              # Flask app + REST endpoints (port 5600)
├── player.py            # mpv IPC controller + playlist/repeat logic
├── config.py             # persists the configured audio folder path
├── player_config.json    # saved settings (audio_dir)
├── requirements.txt
├── ec3-player.service    # systemd unit for headless autostart
├── templates/
│   └── index.html       # GUI page
└── static/
    ├── style/player.css
    └── audio/           # (unused placeholder — tracks are read from
                          #  the configured folder, not this one)
```

## Running alongside the existing AVR9 command GUI

This app is fully independent — different Flask process, different
port (5600 vs 5500), no shared code, and it never touches the UART
serial port. You can run both with something like:

```bash
# terminal / service 1 — existing AVR9 command GUI
cd RPI_UART_AVR9 && python3 main.py

# terminal / service 2 — this audio player GUI
cd EC3_AudioPlayer && python3 main.py
```

For production use on the Pi, see `ec3-player.service` (and
`SETUP_AND_DIAGNOSTICS.md` for the autostart steps) to run it as a
systemd service that starts on boot and restarts if it crashes.

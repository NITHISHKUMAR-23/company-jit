// ItfHeadlessRunner.cs
// NEW FILE — add to AutomationGuiTool project.
//
// This is the CI/CD entry point for ITF. It does the same steps your GUI's
// "Start Automation" button does (ITF_Automation_UI.RunTest_Click), but:
//   - reads every path/setting from config.json instead of GUI controls
//   - never shows a MessageBox — every warning/error goes to RunLogger
//   - a per-test-case failure or a validation warning SKIPS that test case
//     and continues with the next one (per your requirement), it does not
//     stop the whole run
//   - a failure to configure the A2B Ctrl App itself (Stage 2) DOES stop
//     the whole run, because no test case can run without a connected board
//
// It calls AutomationFramework.exe once, as a separate process, to do the
// one-time manual-configuration step (launch A2BCtrlApp, connect, select
// Amp/Mode/SoundMode, run Discovery). AutomationFramework's own ITFAutomation
// class already leaves the app open afterwards (it does not close it at the
// end) — so once that process exits successfully, A2BCtrlApp is left running
// and configured, and the existing ItfAutomation class in this project
// attaches to that same running instance for every test case, exactly like
// it does today. AutomationFramework.exe is only ever run ONCE per full
// session, never once per test case — that's what avoids the slow
// close/reopen/configure cycle.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using Newtonsoft.Json;

namespace AutomationGuiTool
{
    public static class ItfHeadlessRunner
    {
        public static int Run(string configPath)
        {
            RunLogger.Init();
            RunLogger.Log("Startup", "Headless run started. Config: " + configPath);

            HeadlessConfig config;
            try
            {
                string json = File.ReadAllText(configPath);
                config = JsonConvert.DeserializeObject<HeadlessConfig>(json);
            }
            catch (Exception ex)
            {
                RunLogger.LogError("Startup", "Failed to read/parse config.json: " + ex.Message);
                return 1;
            }

            if (config?.ITF == null || !config.ITF.Enabled)
            {
                RunLogger.Log("ITF", "ITF automation disabled in config.json (ITF.Enabled = false). Skipping.");
                return 0;
            }

            return RunItf(config.ITF);
        }

        private static int RunItf(ItfHeadlessConfig itf)
        {
            // ── Stage 1 : required field / path validation ──────────────────
            var missing = new List<string>();
            string frameworkExePath = ResolvePath(itf.AutomationFrameworkExePath);

            if (string.IsNullOrWhiteSpace(itf.AutomationFrameworkExePath) || !File.Exists(frameworkExePath))
                missing.Add($"AutomationFrameworkExePath not found: {itf.AutomationFrameworkExePath}");

            if (string.IsNullOrWhiteSpace(itf.TestPlanExcelPath) || !File.Exists(ResolvePath(itf.TestPlanExcelPath)))
                missing.Add($"TestPlanExcelPath not found: {itf.TestPlanExcelPath}");

            if (string.IsNullOrWhiteSpace(itf.TestSheetName))
                missing.Add("TestSheetName is empty");

            if (string.IsNullOrWhiteSpace(itf.ApxProjectFilePath) || !File.Exists(ResolvePath(itf.ApxProjectFilePath)))
                missing.Add($"ApxProjectFilePath not found: {itf.ApxProjectFilePath}");

            if (string.IsNullOrWhiteSpace(itf.InputWaveFolder) || !Directory.Exists(ResolvePath(itf.InputWaveFolder)))
                missing.Add($"InputWaveFolder not found: {itf.InputWaveFolder}");

            if (string.IsNullOrWhiteSpace(itf.OutputRecordFolder))
                missing.Add("OutputRecordFolder is empty");

            ItfVariant variant = ItfVariant.Alpha1;
            if (string.IsNullOrWhiteSpace(itf.ItfVariant) || !Enum.TryParse(itf.ItfVariant, out variant))
                missing.Add($"ItfVariant invalid (use \"Alpha1\" or \"Alpha2\"): {itf.ItfVariant}");

            if (missing.Count > 0)
            {
                RunLogger.LogError("PathValidation",
                    "Required ITF fields missing/invalid — fix config.json and re-run:\n - " +
                    string.Join("\n - ", missing));
                return 1;
            }

            RunLogger.Log("PathValidation", "All required ITF fields present and valid.");

            string testPlanPath = ResolvePath(itf.TestPlanExcelPath);
            string apxPath = ResolvePath(itf.ApxProjectFilePath);
            string inputWaveFolder = ResolvePath(itf.InputWaveFolder);
            string outputFolder = ResolvePath(itf.OutputRecordFolder);
            Directory.CreateDirectory(outputFolder);

            // ── Stage 2 : one-time A2B Ctrl App configuration ───────────────
            RunLogger.Log("ItfConfigure", "Launching AutomationFramework.exe to configure A2B Ctrl App (one time, board discovery + mode setup)...");

            string frameworkDir = Path.GetDirectoryName(frameworkExePath);

            var psi = new ProcessStartInfo
            {
                FileName = frameworkExePath,
                WorkingDirectory = frameworkDir,   // must match, so Framework's own config.json / relative exe paths resolve
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = false             // ITF UI automation needs a real, visible window
            };

            int exitCode;
            string stdOut, stdErr;

            try
            {
                using (var proc = Process.Start(psi))
                {
                    stdOut = proc.StandardOutput.ReadToEnd();
                    stdErr = proc.StandardError.ReadToEnd();
                    proc.WaitForExit();
                    exitCode = proc.ExitCode;
                }
            }
            catch (Exception ex)
            {
                RunLogger.LogError("ItfConfigure", "Could not start AutomationFramework.exe: " + ex.Message);
                return 1;
            }

            RunLogger.Log("ItfConfigure", "AutomationFramework.exe exit code: " + exitCode);
            if (!string.IsNullOrWhiteSpace(stdOut)) RunLogger.Log("ItfConfigure", "Output:\n" + stdOut);
            if (!string.IsNullOrWhiteSpace(stdErr)) RunLogger.LogError("ItfConfigure", "Error output:\n" + stdErr);

            bool discoveryFailed = false;
            string latestReport = GetLatestFile(Path.Combine(frameworkDir, "ITF_report_logs", "report"));
            if (latestReport != null)
            {
                string reportText = File.ReadAllText(latestReport);
                RunLogger.Log("ItfConfigure", "Discovery report (" + Path.GetFileName(latestReport) + "):\n" + reportText);
                discoveryFailed = reportText.Contains("FAIL");
            }

            if (exitCode != 0 || discoveryFailed)
            {
                RunLogger.LogError("ItfConfigure",
                    "A2B Ctrl App configuration FAILED. Aborting — no test case can run without a connected/configured board. " +
                    "Check the ItfConfigure log and the AutomationFramework report above.");
                return 1;
            }

            RunLogger.Log("ItfConfigure", "A2B Ctrl App configured successfully and left open for test cases.");

            // ── Stage 3 : load + validate the test plan ─────────────────────
            List<ITF_Automation_UI.TestCaseData> testCases;
            try
            {
                testCases = ITF_Automation_UI.ReadTestCasesFromExcel(testPlanPath, itf.TestSheetName);
            }
            catch (Exception ex)
            {
                RunLogger.LogError("TestPlanValidation", "Could not read test plan: " + ex.Message);
                return 1;
            }

            RunLogger.Log("TestPlanValidation", $"Loaded {testCases.Count} test case(s) from sheet '{itf.TestSheetName}'.");

            var excelIssues = ITF_Automation_UI.ValidateTestCaseData(testCases);
            var waveIssues = ITF_Automation_UI.ValidateWaveFiles(testCases, inputWaveFolder);

            foreach (var issue in excelIssues)
                RunLogger.LogWarning("TestPlanValidation", issue + " — test case will be skipped.");
            foreach (var issue in waveIssues)
                RunLogger.LogWarning("WaveFileValidation", issue + " — test case will be skipped.");

            if (excelIssues.Count == 0 && waveIssues.Count == 0)
                RunLogger.Log("TestPlanValidation", "No validation issues found.");

            // ── Stage 4 : init APx ───────────────────────────────────────────
            try
            {
                RunLogger.Log("Apx", "Initializing APx with project: " + apxPath);
                Apxdll.Initialize(apxPath);
                RunLogger.Log("Apx", "APx ready.");
            }
            catch (Exception ex)
            {
                RunLogger.LogError("Apx", "APx initialization failed, aborting run: " + ex.Message);
                return 1;
            }

            ItfAutomation.CurrentVariant = variant;
            RunLogger.Log("ITF", "ITF variant set to: " + variant);

            // ── Stage 5 : per-test-case loop ─────────────────────────────────
            int total = testCases.Count(t => !t.Skip);
            int done = 0, passCount = 0, failCount = 0;
            int skipCount = testCases.Count(t => t.Skip);

            try { Process.GetCurrentProcess().PriorityClass = ProcessPriorityClass.BelowNormal; } catch { }

            for (int i = 0; i < testCases.Count; i++)
            {
                var tc = testCases[i];

                if (tc.Skip)
                {
                    RunLogger.LogWarning("Recording", $"TestCase {i + 1} ({tc.uid_output}) skipped (failed validation).");
                    continue;
                }

                done++;
                RunLogger.Log("Recording", $"Running TC {done}/{total} : {tc.uid_output}");

                try
                {
                    string safeUidOutput = CommonPathCleaner.CleanFileName(tc.uid_output);
                    string tcOutputFolder = Path.Combine(outputFolder, safeUidOutput);
                    Directory.CreateDirectory(tcOutputFolder);

                    string safeInputFile = CommonPathCleaner.CleanExcelCell(tc.InputPath);
                    string inputPath = Path.Combine(inputWaveFolder, safeInputFile);

                    if (!File.Exists(inputPath))
                    {
                        RunLogger.LogWarning("Recording", $"TestCase {i + 1} ({tc.uid_output}): wave file not found -> {inputPath}. Skipping.");
                        skipCount++;
                        continue;
                    }

                    Thread.Sleep(5000); // matches existing GUI timing (tap control settle)

                    List<string> executedCommands = ItfAutomation.itfTestCaseSelector(tc.Command, tc.StepValue);
                    Thread.Sleep(2000);

                    Apxdll.StartMeasurementRecorder(inputPath, safeUidOutput, tcOutputFolder);
                    Thread.Sleep(300);

                    AudioAnalyzer.StartProcess(testPlanPath, itf.TestSheetName, tcOutputFolder, tc.Write_Data)
                        .GetAwaiter().GetResult();

                    if (executedCommands != null && executedCommands.Count > 0)
                        ItfAutomation.RevertCommands(executedCommands);

                    Thread.Sleep(1000);

                    RunLogger.Log("Recording", $"TestCase {i + 1} ({tc.uid_output}) completed.");
                    passCount++;
                }
                catch (Exception ex)
                {
                    failCount++;
                    RunLogger.LogError("Recording", $"TestCase {i + 1} ({tc.uid_output}) FAILED: {ex.Message}. Skipping to next test case.");
                    continue;
                }
            }

            RunLogger.Log("Summary",
                $"ITF automation finished. Total={testCases.Count}, Passed={passCount}, Skipped={skipCount}, Failed={failCount}.");

            return 0;
        }

        private static string ResolvePath(string path)
        {
            if (string.IsNullOrWhiteSpace(path))
                return path;

            return Path.IsPathRooted(path)
                ? path
                : Path.Combine(AppDomain.CurrentDomain.BaseDirectory, path);
        }

        private static string GetLatestFile(string folder)
        {
            if (!Directory.Exists(folder))
                return null;

            return Directory.GetFiles(folder)
                .OrderByDescending(File.GetLastWriteTime)
                .FirstOrDefault();
        }
    }
}

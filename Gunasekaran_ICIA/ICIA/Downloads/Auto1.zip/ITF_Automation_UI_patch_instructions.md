# ITF_Automation_UI.cs — 4 small edits (do NOT replace the whole file)

Open `ITF_Automation_UI.cs` in Visual Studio and make these 4 exact
find-and-replace edits. Nothing else in this file changes. This only makes
two existing private methods reusable by `ItfHeadlessRunner.cs` — your
existing "Start Automation" button behaves exactly the same as before.

---

### Edit 1 — line ~649

**Find:**
```csharp
private List<string> ValidateTestCaseData(List<TestCaseData> testCases)
```

**Replace with:**
```csharp
public static List<string> ValidateTestCaseData(List<TestCaseData> testCases)
```

---

### Edit 2 — line ~683

**Find:**
```csharp
private List<string> ValidateWaveFiles(List<TestCaseData> testCases)
```

**Replace with:**
```csharp
public static List<string> ValidateWaveFiles(List<TestCaseData> testCases, string inputFolder)
```

---

### Edit 3 — line ~687 (inside the method you just changed)

**Find:**
```csharp
            if (string.IsNullOrEmpty(selectedInputFolder))
                return issues;
```

**Replace with:**
```csharp
            if (string.IsNullOrEmpty(inputFolder))
                return issues;
```

---

### Edit 4 — line ~698 (also inside that method)

**Find:**
```csharp
                string fullPath = Path.Combine(selectedInputFolder, safeInputPath);
```

**Replace with:**
```csharp
                string fullPath = Path.Combine(inputFolder, safeInputPath);
```

---

### Edit 5 — line ~359 (the one call site that used the old signature)

**Find:**
```csharp
                var fileIssues  = ValidateWaveFiles(testCases);
```

**Replace with:**
```csharp
                var fileIssues  = ValidateWaveFiles(testCases, selectedInputFolder);
```

That's it — 5 small text changes, nothing structural. Your manual GUI
"Start Automation" button still works exactly as it does today.

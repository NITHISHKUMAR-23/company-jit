// RunLogger.cs
// NEW FILE — add to AutomationGuiTool project.
//
// Replaces MessageBox.Show(...) for headless runs. Every validation stage
// gets its own folder under Logs\, and everything also gets appended to one
// master file Logs\AllLogs.txt so you can check either the specific stage
// or the whole run in one place.
//
// Folder layout produced (relative to AutomationGuiTool.exe):
//   Logs\
//     AllLogs.txt                     <- everything, in order
//     PathValidation\PathValidation.txt
//     ItfConfigure\ItfConfigure.txt
//     TestPlanValidation\TestPlanValidation.txt
//     WaveFileValidation\WaveFileValidation.txt
//     Recording\Recording.txt
//     Summary\Summary.txt

using System;
using System.IO;

namespace AutomationGuiTool
{
    public static class RunLogger
    {
        private static string _logsRoot;
        private static string _masterLogFile;
        private static readonly object _lock = new object();

        public static void Init(string logsRoot = null)
        {
            _logsRoot = logsRoot ?? Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Logs");
            Directory.CreateDirectory(_logsRoot);
            _masterLogFile = Path.Combine(_logsRoot, "AllLogs.txt");
            WriteMaster($"==================== Run started {DateTime.Now:yyyy-MM-dd HH:mm:ss} ====================");
        }

        public static void Log(string stage, string message) => Write(stage, "INFO", message);
        public static void LogWarning(string stage, string message) => Write(stage, "WARNING", message);
        public static void LogError(string stage, string message) => Write(stage, "ERROR", message);

        private static void Write(string stage, string level, string message)
        {
            lock (_lock)
            {
                if (_logsRoot == null)
                    Init();

                string stageFolder = Path.Combine(_logsRoot, SanitizeFolderName(stage));
                Directory.CreateDirectory(stageFolder);

                string line = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] [{level}] {message}";

                string stageFile = Path.Combine(stageFolder, $"{SanitizeFolderName(stage)}.txt");
                File.AppendAllText(stageFile, line + Environment.NewLine);

                WriteMaster($"[{stage}] {line}");
            }
        }

        private static void WriteMaster(string line)
        {
            File.AppendAllText(_masterLogFile, line + Environment.NewLine);
        }

        private static string SanitizeFolderName(string name)
        {
            foreach (char c in Path.GetInvalidFileNameChars())
                name = name.Replace(c, '_');
            return name;
        }
    }
}

// Program.cs  (UPDATED — replaces AutomationGuiTool/Program.cs)
//
// Since config.json is shipped as Content with the release build, it will
// always be sitting next to AutomationGuiTool.exe for your CI/CD users —
// so the release build always runs headless, with zero GUI interaction.
// If someone deletes/renames config.json (e.g. for manual dev testing),
// it falls back to opening MainWindow exactly like today.

using System;
using System.IO;
using System.Windows.Forms;

namespace AutomationGuiTool
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            string configPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "config.json");

            if (File.Exists(configPath))
            {
                int exitCode = ItfHeadlessRunner.Run(configPath);
                Environment.Exit(exitCode);
            }
            else
            {
                Application.Run(new MainWindow());
            }
        }
    }
}

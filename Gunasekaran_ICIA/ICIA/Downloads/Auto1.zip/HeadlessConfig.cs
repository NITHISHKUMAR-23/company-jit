// HeadlessConfig.cs
// NEW FILE — add to AutomationGuiTool project.
//
// This is the shape of config.json. Everything the GUI used to ask you to
// click/upload is now a field here instead. TeraTerm/NFNC sections exist so
// the same config.json can grow later without changing its structure, but
// they are not wired up yet (only ITF is implemented in this pass).

using System.Collections.Generic;

namespace AutomationGuiTool
{
    public class HeadlessConfig
    {
        public ItfHeadlessConfig ITF { get; set; }

        public TeraTermHeadlessConfig TeraTerm { get; set; }   // reserved — not used yet

        public NfncHeadlessConfig NFNC { get; set; }           // reserved — not used yet

        public bool JAQMS { get; set; }                        // reserved — not used yet
    }

    public class ItfHeadlessConfig
    {
        // Set to false to skip ITF automation entirely for this run.
        public bool Enabled { get; set; } = true;

        // Path to AutomationFramework.exe (the project that does the one-time
        // manual configuration: launch A2BCtrlApp, connect, discovery, etc).
        // Relative paths are resolved against the AutomationGuiTool.exe folder.
        public string AutomationFrameworkExePath { get; set; }

        // Qualified test plan (Excel) — same file you used to upload by hand.
        public string TestPlanExcelPath { get; set; }

        // Sheet name inside that Excel file to run (the "qualified test sheet").
        public string TestSheetName { get; set; }

        // Saved APx project file (.approj).
        public string ApxProjectFilePath { get; set; }

        // Folder containing the input wave files.
        public string InputWaveFolder { get; set; }

        // Folder where recorded output wave files should be written.
        public string OutputRecordFolder { get; set; }

        // ITF version dropdown from the GUI: "Alpha1" or "Alpha2".
        public string ItfVariant { get; set; }
    }

    public class TeraTermHeadlessConfig
    {
        public bool Enabled { get; set; } = false;
        public string CommandFolder { get; set; }
    }

    public class NfncHeadlessConfig
    {
        public bool Enabled { get; set; } = false;
        public string CommandFolder { get; set; }
    }
}

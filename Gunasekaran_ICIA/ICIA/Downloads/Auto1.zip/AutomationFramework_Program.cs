// Program.cs  (UPDATED — replaces AutomationFramework/Program.cs)
//
// Important for CI: an unhandled exception in a WinExe app pops a Windows
// "stopped working" / unhandled exception dialog and just sits there
// forever waiting for someone to click it — which hangs your CI job.
// Wrapping Run() in try/catch and setting Environment.ExitCode avoids that,
// and gives AutomationGuiTool.exe a real exit code to check.

using System;
using System.Windows.Forms;

namespace AutomationFramework
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            try
            {
                ITF.ITFAutomation.Run();
                // TeraTerm will start here
                // NFNC will start here

                Environment.ExitCode = 0;
            }
            catch (Exception ex)
            {
                Console.WriteLine("AutomationFramework FAILED: " + ex.Message);
                Environment.ExitCode = 1;
            }
        }
    }
}

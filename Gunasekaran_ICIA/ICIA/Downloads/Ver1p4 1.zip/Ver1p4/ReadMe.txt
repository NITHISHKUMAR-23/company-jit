Modules without Dirac is supported (Internal Updated Demo App)
----------------------------------------
Ver1p0:
Individual Channel Mute is added
----------------------------------
Ver1p1:
VolumeControl is added as per command protocol
-----------------------------------
Ver1p2
Individual Mute channel swapping issue is updated.
-----------------------------------
Ver1p3
Mute All updated using 'for loop' for individual mute commands.
-----------------------------------
Ver1p4
Mute All updated using single command due to the delay process handled in previous version.
from flask import Flask, request, render_template, jsonify
import serial
from flask_cors import CORS

# ---------- Serial ----------
# Adjust the port if needed (e.g., /dev/ttyAMA0 or COMx on Windows)
ser = serial.Serial(
    port='/dev/ttyUSB0',
    baudrate=115200,
    bytesize=8,
    parity='N',
    stopbits=1,
    timeout=2
)

# ---------- Flask ----------
app = Flask(__name__, static_folder='static')
CORS(app)

# Command constants
CMD_MUTE        = "0x20000023"
CMD_VOL_APPLY   = "0x20000022"

CMD_MUTE_ENABLE  = "0x20010040"
CMD_MUTE_DISABLE = "0x20010080"

# Balance/Fader binary opcodes
CMD_BAL  = 0x06
CMD_FADE = 0x07

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

# ---------- Helpers ----------
def write_line(cmd_str: str):
    """Write an ASCII hex command with CR."""
    ser.write((cmd_str + '\r').encode('utf-8'))

def spk_on_off_cmds(spk_index: int, enable: bool) -> str:
    """
    Build the per-speaker on/off command:
    enable:  0x20010000 + (spk-1)
    disable: 0x20010020 + (spk-1)
    """
    base = 0x20010000 if enable else 0x20010020
    value = base + (spk_index - 1)
    return f"0x{value:08X}"

def clamp(v, lo, hi):
    return max(lo, min(hi, v))

# ---------- API ----------
@app.post('/api/mute_all')
def mute_all():
    """
    Expects JSON: { "toggleId": "mute_all" | "spk1".. "spk18", "isChecked": true/false }
    Returns JSON.
    """
    try:
        data = request.get_json(force=True) or {}
        toggle_id = str(data.get('toggleId', '')).strip()
        is_checked = data.get('isChecked')

        # Coerce JS boolean / int-like to Python bool
        if isinstance(is_checked, str):
            is_checked = is_checked.lower() in ('1', 'true', 'yes', 'on')
        elif isinstance(is_checked, (int, float)):
            is_checked = bool(is_checked)
        elif not isinstance(is_checked, bool):
            is_checked = False

        if toggle_id == "mute_all":
            # Global mute
            write_line(CMD_MUTE_ENABLE if is_checked else CMD_MUTE_DISABLE)
            write_line(CMD_MUTE)
            return jsonify({"ok": True, "target": "mute_all", "state": is_checked})

        # Speaker toggles: spk1..spk18
        if toggle_id.startswith("spk"):
            try:
                spk_index = int(toggle_id.replace("spk", ""))
            except ValueError:
                return jsonify({"ok": False, "error": "Invalid speaker id"}), 400

            if not (1 <= spk_index <= 18):
                return jsonify({"ok": False, "error": "Speaker index out of range"}), 400

            cmd = spk_on_off_cmds(spk_index, is_checked)
            write_line(cmd)
            write_line(CMD_MUTE)  # your original code sends the mute op after each channel command
            return jsonify({"ok": True, "target": toggle_id, "state": is_checked, "cmd": cmd})

        return jsonify({"ok": False, "error": "Unknown toggleId"}), 400

    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500


@app.post('/api/volume')
def volume():
    """
    Expects JSON: { "command": <int 0..30> }
    Sends:
      - "0x2001" + HEX(level, 4 digits)
      - CMD_VOL_APPLY
    Returns JSON.
    """
    try:
        level = int(request.json.get('command'))
        level = clamp(level, 0, 30)
        vol_data = "0x2001" + f"{level:04X}"

        print(f"[VOLUME] -> {vol_data}")
        write_line(vol_data)
        write_line(CMD_VOL_APPLY)

        return jsonify({"ok": True, "level": level, "sent": [vol_data, CMD_VOL_APPLY]})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500


@app.post('/api/balance_level')
def balance():
    """
    Expects JSON: { "command": <int -7..7> }
    Sends binary: [0x06, 0x00, (cmd+7), 0x04]
    """
    try:
        val = int(request.json.get('command'))
        val = clamp(val, -7, 7)
        encoded = val + 7  # 0..14
        payload = bytearray([CMD_BAL, 0x00, encoded, 0x04])

        ser.write(payload)
        print(f"[BALANCE] -> {list(payload)}")

        return jsonify({"ok": True, "value": val, "sent": list(payload)})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500


@app.post('/api/fader')
def fader():
    """
    Expects JSON: { "command": <int -7..7> }
    Sends binary: [0x07, 0x00, (cmd+7), 0x04]
    """
    try:
        val = int(request.json.get('command'))
        val = clamp(val, -7, 7)
        encoded = val + 7  # 0..14
        payload = bytearray([CMD_FADE, 0x00, encoded, 0x04])

        ser.write(payload)
        print(f"[FADER] -> {list(payload)}")

        return jsonify({"ok": True, "value": val, "sent": list(payload)})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500


if __name__ == '__main__':
    # IMPORTANT: listen on all interfaces so other devices on AP can reach it
    app.run(debug=True, host='0.0.0.0', port=5700, threaded=True)
